# Django Educational Platform - Deployment Guide

## Project Overview
This is a Django-based educational platform with course management, user authentication, and task submission features.

## Prerequisites
- Python 3.8+
- MySQL 8.0+
- Web server (Apache/Nginx)

## Installation Steps

### 1. Clone and Setup
```bash
git clone <your-repository>
cd study
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Environment Configuration
```bash
cp .env.example .env
# Edit .env file with your production settings
```

### 5. Database Setup
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
```

### 6. Collect Static Files
```bash
python manage.py collectstatic --noinput
```

### 7. Production Settings
- Set DEBUG=False in .env
- Configure ALLOWED_HOSTS with your domain
- Set up proper SECRET_KEY
- Configure database credentials
- Set up email configuration

## Features Included
- User authentication (Admin, Trainer, Student roles)
- Course management with enrollment
- Task submission system with timer
- MCQ tests with auto-grading
- File upload functionality
- Newsletter subscription
- Contact form
- Responsive design

## Security Features
- CSRF protection
- XSS protection
- Secure headers for production
- Environment-based configuration

## File Structure
```
study/
├── basic/                 # Main Django app
├── media/                 # User uploaded files
├── staticfiles/          # Collected static files
├── templates/            # HTML templates
├── manage.py
├── requirements.txt
└── .env.example
```

## Production Checklist
- [ ] Set DEBUG=False
- [ ] Configure ALLOWED_HOSTS
- [ ] Set up SSL certificate
- [ ] Configure database backups
- [ ] Set up monitoring
- [ ] Configure email settings
- [ ] Test all functionality

## Support
For issues or questions, contact the development team.