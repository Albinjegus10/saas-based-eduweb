# admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User, Category, Trainer, Course, CourseModule, 
    Enrollment, CourseLike, Event, Newsletter, 
    ContactMessage, EventAttendance, CourseNote,
    Organization, SubscriptionPlan, Subscription, Payment, PaymentGateway
)

# ----------------------------
# Custom User Admin
# ----------------------------
class UserAdmin(BaseUserAdmin):
    model = User
    list_display = ('email', 'username', 'first_name', 'last_name', 'role', 'organization', 'is_verified', 'is_active', 'created_at')
    list_filter = ('role', 'organization', 'is_verified', 'is_active', 'is_staff', 'is_superuser')
    search_fields = ('email', 'username', 'first_name', 'last_name')
    ordering = ('-created_at',)
    readonly_fields = ('created_at', 'updated_at')
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs  # Superuser sees all users
        elif request.user.role == 'admin' and request.user.organization:
            return qs.filter(organization=request.user.organization)  # Org admin sees only their users
        return qs.none()  # Others see nothing
    
    def has_add_permission(self, request):
        return request.user.is_superuser or (request.user.role == 'admin' and request.user.organization)
    
    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser:
            return True
        if request.user.role == 'admin' and request.user.organization:
            if obj is None:
                return True
            return obj.organization == request.user.organization
        return False

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('username', 'first_name', 'last_name', 'phone', 'avatar')}),
        ('Organization', {'fields': ('organization', 'role')}),
        ('Permissions', {'fields': ('is_verified', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined', 'created_at', 'updated_at')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'first_name', 'last_name', 'organization', 'role', 'password1', 'password2')}
        ),
    )
    
    def save_model(self, request, obj, form, change):
        if not change and not request.user.is_superuser:
            # Auto-assign organization for non-superuser admins
            obj.organization = request.user.organization
        super().save_model(request, obj, form, change)

admin.site.register(User, UserAdmin)


# ----------------------------
# Category Admin
# ----------------------------
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'organization', 'slug', 'is_active', 'created_at')
    list_filter = ('organization', 'is_active')
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ('name',)
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        elif request.user.role == 'admin' and request.user.organization:
            return qs.filter(organization=request.user.organization)
        return qs.none()


# ----------------------------
# Trainer Admin
# ----------------------------
@admin.register(Trainer)
class TrainerAdmin(admin.ModelAdmin):
    list_display = ('user', 'expertise', 'experience_years', 'rating', 'is_active', 'created_at')
    list_filter = ('is_active',)
    search_fields = ('user__first_name', 'user__last_name', 'expertise')


# ----------------------------
# Course Admin
# ----------------------------
@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'organization', 'trainer', 'category', 'difficulty_level', 'price', 'available_seats', 'is_active', 'created_at')
    list_filter = ('organization', 'difficulty_level', 'is_featured', 'is_active', 'category')
    search_fields = ('title', 'trainer__user__first_name', 'trainer__user__last_name')
    prepopulated_fields = {'slug': ('title',)}
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs
        elif request.user.role == 'admin' and request.user.organization:
            return qs.filter(organization=request.user.organization)
        return qs.none()


# ----------------------------
# CourseModule Admin
# ----------------------------
@admin.register(CourseModule)
class CourseModuleAdmin(admin.ModelAdmin):
    list_display = ('course', 'title', 'order', 'duration_hours', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('title', 'course__title')


# ----------------------------
# Enrollment Admin
# ----------------------------
@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'status', 'progress', 'is_active', 'enrolled_date')
    list_filter = ('status', 'is_active')
    search_fields = ('user__email', 'course__title')


# ----------------------------
# CourseLike Admin
# ----------------------------
@admin.register(CourseLike)
class CourseLikeAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'created_at')
    search_fields = ('user__email', 'course__title')


# ----------------------------
# Event Admin
# ----------------------------
@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'trainer', 'date', 'duration_hours', 'is_online', 'price', 'is_active')
    list_filter = ('is_online', 'is_active')
    search_fields = ('title', 'trainer__user__first_name', 'trainer__user__last_name')
    prepopulated_fields = {'slug': ('title',)}


# ----------------------------
# Newsletter Admin
# ----------------------------
@admin.register(Newsletter)
class NewsletterAdmin(admin.ModelAdmin):
    list_display = ('email', 'is_active', 'subscribed_date')
    list_filter = ('is_active',)
    search_fields = ('email',)


# ----------------------------
# ContactMessage Admin
# ----------------------------
@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'is_read', 'created_at')
    list_filter = ('is_read',)
    search_fields = ('name', 'email', 'subject')


# ----------------------------
# EventAttendance Admin
# ----------------------------
@admin.register(EventAttendance)
class EventAttendanceAdmin(admin.ModelAdmin):
    list_display = ('event', 'user', 'status', 'check_in_time', 'check_out_time', 'created_at')
    list_filter = ('status',)
    search_fields = ('event__title', 'user__email')

# Add this to your admin.py file

from django.contrib import admin
from .models import Task, MCQQuestion, TaskSubmission, MCQResponse

class MCQQuestionInline(admin.TabularInline):
    """Inline for MCQ questions within Task admin"""
    model = MCQQuestion
    extra = 1
    fields = ('question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer', 'points', 'order')

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    """Admin interface for Task model"""
    list_display = ('title', 'course', 'task_type', 'points', 'due_date', 'is_active', 'created_at')
    list_filter = ('task_type', 'is_active', 'course', 'created_at')
    search_fields = ('title', 'description', 'course__title')
    ordering = ('course', 'order', 'created_at')
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('course', 'title', 'description', 'task_type')
        }),
        ('Settings', {
            'fields': ('points', 'time_limit', 'due_date', 'order', 'is_active')
        }),
    )
    
    # Add MCQ questions inline for MCQ tests
    inlines = [MCQQuestionInline]
    
    def get_inlines(self, request, obj):
        """Only show MCQ inline for MCQ test tasks"""
        if obj and obj.task_type == 'mcq_test':
            return [MCQQuestionInline]
        return []

@admin.register(MCQQuestion)
class MCQQuestionAdmin(admin.ModelAdmin):
    """Admin interface for MCQ Question model"""
    list_display = ('get_task_title', 'get_task_type', 'question_preview', 'correct_answer', 'points', 'order')
    list_filter = ('task__course', 'task__task_type', 'correct_answer')
    search_fields = ('question_text', 'task__title')
    ordering = ('task', 'order')
    
    fieldsets = (
        ('Question', {
            'fields': ('task', 'question_text', 'order', 'points')
        }),
        ('Options', {
            'fields': ('option_a', 'option_b', 'option_c', 'option_d', 'correct_answer')
        }),
    )
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "task":
            kwargs["queryset"] = Task.objects.select_related('course').all()
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    def get_task_title(self, obj):
        return f"{obj.task.course.title} - {obj.task.title}"
    get_task_title.short_description = 'Task'
    get_task_title.admin_order_field = 'task__title'
    
    def get_task_type(self, obj):
        return obj.task.get_task_type_display()
    get_task_type.short_description = 'Type'
    get_task_type.admin_order_field = 'task__task_type'
    
    def question_preview(self, obj):
        return obj.question_text[:50] + "..." if len(obj.question_text) > 50 else obj.question_text
    question_preview.short_description = 'Question Preview'

@admin.register(TaskSubmission)
class TaskSubmissionAdmin(admin.ModelAdmin):
    """Admin interface for Task Submission model"""
    list_display = ('get_user_name', 'get_task_title', 'get_course_title', 'status', 'score', 'submitted_at')
    list_filter = ('status', 'task__course', 'task__task_type', 'submitted_at', 'graded_at')
    search_fields = ('user__first_name', 'user__last_name', 'user__email', 'task__title')
    readonly_fields = ('submitted_at',)
    ordering = ('-submitted_at',)
    
    fieldsets = (
        ('Submission Info', {
            'fields': ('user', 'task', 'status', 'submitted_at')
        }),
        ('Content', {
            'fields': ('submission_text', 'file_upload')
        }),
        ('Grading', {
            'fields': ('score', 'max_score', 'feedback', 'graded_at')
        }),
    )
    
    def get_user_name(self, obj):
        return obj.user.get_full_name() or obj.user.username
    get_user_name.short_description = 'Student'
    get_user_name.admin_order_field = 'user__first_name'
    
    def get_task_title(self, obj):
        return obj.task.title
    get_task_title.short_description = 'Task'
    get_task_title.admin_order_field = 'task__title'
    
    def get_course_title(self, obj):
        return obj.task.course.title
    get_course_title.short_description = 'Course'
    get_course_title.admin_order_field = 'task__course__title'
    
    # Auto-set graded_at when status changes to graded
    def save_model(self, request, obj, form, change):
        if obj.status == 'graded' and not obj.graded_at:
            from django.utils import timezone
            obj.graded_at = timezone.now()
        super().save_model(request, obj, form, change)

@admin.register(MCQResponse)
class MCQResponseAdmin(admin.ModelAdmin):
    """Admin interface for MCQ Response model"""
    list_display = ('get_user_name', 'get_question_preview', 'selected_answer', 'is_correct', 'answered_at')
    list_filter = ('is_correct', 'selected_answer', 'question__task__course', 'answered_at')
    search_fields = ('user__first_name', 'user__last_name', 'question__question_text')
    readonly_fields = ('is_correct', 'answered_at')
    ordering = ('-answered_at',)
    
    def get_user_name(self, obj):
        return obj.user.get_full_name() or obj.user.username
    get_user_name.short_description = 'Student'
    get_user_name.admin_order_field = 'user__first_name'
    
    def get_question_preview(self, obj):
        return obj.question.question_text[:30] + "..." if len(obj.question.question_text) > 30 else obj.question.question_text
    get_question_preview.short_description = 'Question'

# Custom Admin Actions
@admin.action(description='Mark selected tasks as active')
def mark_tasks_active(modeladmin, request, queryset):
    queryset.update(is_active=True)

@admin.action(description='Mark selected tasks as inactive')
def mark_tasks_inactive(modeladmin, request, queryset):
    queryset.update(is_active=False)

@admin.action(description='Mark submissions as graded')
def mark_submissions_graded(modeladmin, request, queryset):
    from django.utils import timezone
    queryset.update(status='graded', graded_at=timezone.now())

# Add actions to TaskAdmin
TaskAdmin.actions = [mark_tasks_active, mark_tasks_inactive]
TaskSubmissionAdmin.actions = [mark_submissions_graded]

# ----------------------------
# CourseNote Admin
# ----------------------------
@admin.register(CourseNote)
class CourseNoteAdmin(admin.ModelAdmin):
    """Admin interface for Course Notes with visibility control"""
    list_display = ('title', 'course', 'trainer', 'file_type', 'file_size_mb', 'is_restricted', 'visible_students_count', 'is_active', 'created_at')
    list_filter = ('file_type', 'is_active', 'is_restricted', 'course', 'trainer', 'created_at')
    search_fields = ('title', 'description', 'course__title', 'trainer__user__first_name', 'trainer__user__last_name')
    ordering = ('course', 'order', '-created_at')
    readonly_fields = ('file_type', 'file_size', 'created_at', 'updated_at')
    filter_horizontal = ('visible_to_students',)
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('course', 'trainer', 'title', 'description')
        }),
        ('File Information', {
            'fields': ('file', 'file_type', 'file_size')
        }),
        ('Visibility Control', {
            'fields': ('is_restricted', 'visible_to_students'),
            'description': 'Control which students can view this note. If "Is restricted" is unchecked, all enrolled students can view. If checked, only selected students can view.'
        }),
        ('Settings', {
            'fields': ('order', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == "course":
            kwargs["queryset"] = Course.objects.select_related('trainer__user').filter(is_active=True)
        elif db_field.name == "trainer":
            kwargs["queryset"] = Trainer.objects.select_related('user').filter(is_active=True)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)
    
    def formfield_for_manytomany(self, db_field, request, **kwargs):
        if db_field.name == "visible_to_students":
            # Only show students who are enrolled in courses
            kwargs["queryset"] = User.objects.filter(
                role='student',
                enrollments__is_active=True
            ).distinct().order_by('first_name', 'last_name')
        return super().formfield_for_manytomany(db_field, request, **kwargs)
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('course', 'trainer__user').prefetch_related('visible_to_students')
    
    def visible_students_count(self, obj):
        if obj.is_restricted:
            return f"{obj.visible_to_students.count()} selected"
        else:
            # Count enrolled students in the course
            enrolled_count = obj.course.enrollments.filter(is_active=True, user__role='student').count()
            return f"All enrolled ({enrolled_count})"
    visible_students_count.short_description = 'Visible To'
    
    # Add action to quickly restrict/unrestrict notes
    actions = ['make_restricted', 'make_unrestricted']
    
    @admin.action(description='Make selected notes restricted (admin-controlled)')
    def make_restricted(self, request, queryset):
        queryset.update(is_restricted=True)
        self.message_user(request, f"{queryset.count()} notes marked as restricted.")
    
    @admin.action(description='Make selected notes unrestricted (visible to all enrolled)')
    def make_unrestricted(self, request, queryset):
        queryset.update(is_restricted=False)
        self.message_user(request, f"{queryset.count()} notes marked as unrestricted.")
    
    def changelist_view(self, request, extra_context=None):
        extra_context = extra_context or {}
        extra_context['bulk_visibility_url'] = '/admin/notes/visibility/'
        return super().changelist_view(request, extra_context=extra_context)

# Bulk actions for managing student visibility
@admin.action(description='Add selected students to note visibility')
def add_students_to_visibility(modeladmin, request, queryset):
    # This would be used in a custom admin view for bulk operations
    pass

# ----------------------------
# Multi-Tenant SaaS Admin
# ----------------------------
@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'contact_email', 'is_active', 'created_at')
    list_filter = ('is_active', 'created_at')
    search_fields = ('name', 'contact_email')
    prepopulated_fields = {'slug': ('name',)}

@admin.register(SubscriptionPlan)
class SubscriptionPlanAdmin(admin.ModelAdmin):
    list_display = ('name', 'price_monthly', 'price_yearly', 'max_students', 'max_trainers', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)

@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('organization', 'plan', 'status', 'billing_cycle', 'start_date', 'end_date')
    list_filter = ('status', 'billing_cycle', 'plan')
    search_fields = ('organization__name',)

@admin.register(PaymentGateway)
class PaymentGatewayAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'is_active', 'is_test_mode')
    list_filter = ('is_active', 'is_test_mode')

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('organization', 'amount', 'currency', 'status', 'gateway', 'created_at')
    list_filter = ('status', 'gateway', 'currency')
    search_fields = ('organization__name', 'gateway_transaction_id')
    readonly_fields = ('gateway_response', 'created_at')
