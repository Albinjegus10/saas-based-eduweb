from django.contrib import admin
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import CourseNote, Course, User, Enrollment

@staff_member_required
def bulk_note_visibility(request, course_id=None):
    """Bulk manage note visibility for a course"""
    
    if course_id:
        course = get_object_or_404(Course, id=course_id)
        notes = CourseNote.objects.filter(course=course, is_active=True)
        # Get enrolled students for this course
        enrolled_students = User.objects.filter(
            role='student',
            enrollments__course=course,
            enrollments__is_active=True
        ).distinct().order_by('first_name', 'last_name')
    else:
        course = None
        notes = CourseNote.objects.filter(is_active=True)
        # Get all students
        enrolled_students = User.objects.filter(role='student').order_by('first_name', 'last_name')
    
    courses = Course.objects.filter(is_active=True).order_by('title')
    
    if request.method == 'POST':
        action = request.POST.get('action')
        note_ids = request.POST.getlist('note_ids')
        student_ids = request.POST.getlist('student_ids')
        
        if not note_ids:
            messages.error(request, 'Please select at least one note.')
            return redirect(request.path)
        
        selected_notes = CourseNote.objects.filter(id__in=note_ids)
        
        if action == 'make_restricted':
            selected_notes.update(is_restricted=True)
            if student_ids:
                selected_students = User.objects.filter(id__in=student_ids)
                for note in selected_notes:
                    note.visible_to_students.set(selected_students)
            messages.success(request, f'{len(note_ids)} notes made restricted.')
            
        elif action == 'make_unrestricted':
            selected_notes.update(is_restricted=False)
            messages.success(request, f'{len(note_ids)} notes made unrestricted (visible to all enrolled students).')
            
        elif action == 'add_students':
            if student_ids:
                selected_students = User.objects.filter(id__in=student_ids)
                for note in selected_notes.filter(is_restricted=True):
                    note.visible_to_students.add(*selected_students)
                messages.success(request, f'Added {len(student_ids)} students to {len(note_ids)} restricted notes.')
            else:
                messages.error(request, 'Please select students to add.')
                
        elif action == 'remove_students':
            if student_ids:
                selected_students = User.objects.filter(id__in=student_ids)
                for note in selected_notes.filter(is_restricted=True):
                    note.visible_to_students.remove(*selected_students)
                messages.success(request, f'Removed {len(student_ids)} students from {len(note_ids)} restricted notes.')
            else:
                messages.error(request, 'Please select students to remove.')
        
        return redirect(request.path)
    
    context = {
        'course': course,
        'courses': courses,
        'notes': notes,
        'enrolled_students': enrolled_students,
        'title': f'Bulk Note Visibility Management{" - " + course.title if course else ""}',
    }
    
    return render(request, 'admin/bulk_note_visibility.html', context)

@staff_member_required
@require_POST
def ajax_note_visibility(request):
    """AJAX endpoint for quick visibility changes"""
    note_id = request.POST.get('note_id')
    action = request.POST.get('action')
    
    try:
        note = CourseNote.objects.get(id=note_id)
        
        if action == 'toggle_restriction':
            note.is_restricted = not note.is_restricted
            note.save()
            return JsonResponse({
                'success': True,
                'is_restricted': note.is_restricted,
                'message': f'Note {"restricted" if note.is_restricted else "unrestricted"} successfully.'
            })
            
    except CourseNote.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Note not found.'})
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})
    
    return JsonResponse({'success': False, 'message': 'Invalid action.'})