from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from .models import (
    ContactMessage, Newsletter, Course, Trainer, 
    Event, Category, Enrollment, EventAttendance, User, CourseModule, CourseNote, Organization
)

class ContactForm(forms.ModelForm):
    """Form for contact messages"""
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'subject', 'message']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Your Full Name',
                'required': True
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Your Email Address',
                'required': True
            }),
            'subject': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Subject',
                'required': True
            }),
            'message': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Your Message',
                'rows': 6,
                'required': True
            }),
        }

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if len(name) < 2:
            raise ValidationError('Name must be at least 2 characters long.')
        return name

    def clean_message(self):
        message = self.cleaned_data.get('message')
        if len(message) < 10:
            raise ValidationError('Message must be at least 10 characters long.')
        return message

class NewsletterForm(forms.ModelForm):
    """Form for newsletter subscription"""
    class Meta:
        model = Newsletter
        fields = ['email']
        widgets = {
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter your email address',
                'required': True
            })
        }

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if Newsletter.objects.filter(email=email, is_active=True).exists():
            raise ValidationError('This email is already subscribed to our newsletter.')
        return email

class UserRegistrationForm(UserCreationForm):
    """Extended user registration form"""
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'First Name'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Last Name'
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Email Address',
            'autocomplete': 'email'
        })
    )
    role = forms.ChoiceField(
        choices=[('student', 'Student'), ('trainer', 'Trainer')],
        widget=forms.Select(attrs={
            'class': 'form-control'
        }),
        initial='student'
    )
    phone = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phone Number'
        })
    )

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'phone', 'role', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Username',
            'autocomplete': 'username'
        })
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Password',
            'autocomplete': 'new-password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirm Password',
            'autocomplete': 'new-password'
        })

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise ValidationError('A user with this email already exists.')
        return email

class CourseSearchForm(forms.Form):
    """Form for searching and filtering courses"""
    search = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search courses...',
        })
    )
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        empty_label='All Categories',
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )
    price_range = forms.ChoiceField(
        choices=[
            ('', 'Any Price'),
            ('0-50', 'Under $50'),
            ('50-100', '$50 - $100'),
            ('100-200', '$100 - $200'),
            ('200+', 'Above $200'),
        ],
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )
    difficulty = forms.ChoiceField(
        choices=[('', 'Any Level')] + Course.DIFFICULTY_CHOICES,
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )

class CourseForm(forms.ModelForm):
    """Form for creating/editing courses (for trainers/admin)"""
    class Meta:
        model = Course
        fields = [
            'title', 'description', 'short_description', 'category', 
            'price', 'discount_price', 'image', 'difficulty_level',
            'available_seats', 'duration_weeks', 'start_date', 'end_date',
            'schedule_days', 'schedule_start', 'schedule_end', 'is_featured'
        ]
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Course Title'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Course Description'
            }),
            'short_description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Short Description (max 500 chars)'
            }),
            'category': forms.Select(attrs={
                'class': 'form-control'
            }),
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'discount_price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control'
            }),
            'difficulty_level': forms.Select(attrs={
                'class': 'form-control'
            }),
            'available_seats': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
            'duration_weeks': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
            'start_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'end_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'schedule_days': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Mon, Wed, Fri'
            }),
            'schedule_start': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time'
            }),
            'schedule_end': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time'
            }),
            'is_featured': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')
        schedule_start = cleaned_data.get('schedule_start')
        schedule_end = cleaned_data.get('schedule_end')
        discount_price = cleaned_data.get('discount_price')
        price = cleaned_data.get('price')

        # Validate dates
        if start_date and end_date:
            if start_date >= end_date:
                raise ValidationError('End date must be after start date.')

        # Validate schedule times
        if schedule_start and schedule_end:
            if schedule_start >= schedule_end:
                raise ValidationError('Schedule end time must be after start time.')

        # Validate pricing
        if discount_price and price:
            if discount_price >= price:
                raise ValidationError('Discount price must be less than regular price.')

        return cleaned_data

class TrainerProfileForm(forms.ModelForm):
    """Form for trainer profile management"""
    class Meta:
        model = Trainer
        fields = [
            'bio', 'expertise', 'image', 'experience_years', 'hourly_rate',
            'linkedin', 'twitter', 'facebook', 'instagram', 'website'
        ]
        widgets = {
            'bio': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Tell us about yourself and your expertise...'
            }),
            'expertise': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Web Development, Data Science, Digital Marketing'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control'
            }),
            'experience_years': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0'
            }),
            'hourly_rate': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'linkedin': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://linkedin.com/in/yourprofile'
            }),
            'twitter': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://twitter.com/yourprofile'
            }),
            'facebook': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://facebook.com/yourprofile'
            }),
            'instagram': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://instagram.com/yourprofile'
            }),
            'website': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://yourwebsite.com'
            }),
        }

    def clean_bio(self):
        bio = self.cleaned_data.get('bio')
        if len(bio) < 50:
            raise ValidationError('Bio must be at least 50 characters long.')
        return bio

class EventForm(forms.ModelForm):
    """Form for creating/editing events"""
    class Meta:
        model = Event
        fields = [
            'title', 'description', 'image', 'date', 'duration_hours',
            'location', 'is_online', 'meeting_link', 'max_attendees', 'price'
        ]
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Event Title'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 5,
                'placeholder': 'Event Description'
            }),
            'image': forms.FileInput(attrs={
                'class': 'form-control'
            }),
            'date': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'duration_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
            'location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Event Location (if not online)'
            }),
            'is_online': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'meeting_link': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'Online meeting link'
            }),
            'max_attendees': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
            'price': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        is_online = cleaned_data.get('is_online')
        location = cleaned_data.get('location')
        meeting_link = cleaned_data.get('meeting_link')

        if not is_online and not location:
            raise ValidationError('Location is required for offline events.')
        
        if is_online and not meeting_link:
            raise ValidationError('Meeting link is required for online events.')

        return cleaned_data

class EventRegistrationForm(forms.ModelForm):
    """Form for event registration"""
    class Meta:
        model = EventAttendance
        fields = []  # No additional fields needed, user and event are set in view

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        self.event = kwargs.pop('event', None)
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned_data = super().clean()
        
        if self.user and self.event:
            # Check if user already registered
            if EventAttendance.objects.filter(user=self.user, event=self.event).exists():
                raise ValidationError('You are already registered for this event.')
            
            # Check if event is full
            if self.event.max_attendees:
                current_attendees = self.event.attendances.count()
                if current_attendees >= self.event.max_attendees:
                    raise ValidationError('This event is full.')

        return cleaned_data

class UserProfileForm(forms.ModelForm):
    """Form for updating user profile"""
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'phone', 'avatar']
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'First Name'
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Last Name'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Email Address'
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Phone Number'
            }),
            'avatar': forms.FileInput(attrs={
                'class': 'form-control'
            }),
        }

    def __init__(self, *args, **kwargs):
        self.user_id = kwargs.pop('user_id', None)
        super().__init__(*args, **kwargs)

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exclude(id=self.user_id).exists():
            raise ValidationError('A user with this email already exists.')
        return email

class CourseModuleForm(forms.ModelForm):
    """Form for creating/editing course modules"""
    class Meta:
        model = CourseModule
        fields = ['title', 'description', 'duration_hours', 'order']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Module Title'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Module Description'
            }),
            'duration_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
            'order': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1'
            }),
        }

class CategoryForm(forms.ModelForm):
    """Form for creating/editing categories"""
    class Meta:
        model = Category
        fields = ['name', 'description', 'icon']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Category Name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Category Description'
            }),
            'icon': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Icon class (e.g., fas fa-code)'
            }),
        }

class EventAttendanceForm(forms.ModelForm):
    """Form for updating event attendance status (for trainers/admin)"""
    class Meta:
        model = EventAttendance
        fields = ['status', 'remarks']
        widgets = {
            'status': forms.Select(attrs={
                'class': 'form-control'
            }),
            'remarks': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Optional remarks'
            }),
        }

class EnrollmentForm(forms.ModelForm):
    """Form for managing enrollments (for admin/trainers)"""
    class Meta:
        model = Enrollment
        fields = ['status', 'progress']
        widgets = {
            'status': forms.Select(attrs={
                'class': 'form-control'
            }),
            'progress': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '0',
                'max': '100'
            }),
        }

    def clean_progress(self):
        progress = self.cleaned_data.get('progress')
        if progress < 0 or progress > 100:
            raise ValidationError('Progress must be between 0 and 100.')
        return progress

class CustomLoginForm(forms.Form):
    """Custom login form that uses email instead of username"""
    username = forms.EmailField(
        label='Email',
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your email address',
            'required': True
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your password',
            'required': True
        })
    )
    remember_me = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={
            'class': 'form-check-input'
        })
    )

    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        if username and password:
            from django.contrib.auth import authenticate
            user = authenticate(username=username, password=password)
            if not user:
                raise ValidationError('Invalid email or password.')
            if not user.is_active:
                raise ValidationError('This account is inactive.')
            cleaned_data['user'] = user

        return cleaned_data

class CourseNoteForm(forms.ModelForm):
    """Form for uploading course notes (for trainers)"""
    class Meta:
        model = CourseNote
        fields = ['title', 'description', 'file', 'order']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Note Title (e.g., Week 1 - Introduction to Python)'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Brief description of the note content (optional)'
            }),
            'file': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '.pdf,.txt,.jpg,.jpeg,.png,.gif'
            }),
            'order': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '1',
                'value': '1'
            }),
        }
    
    def clean_file(self):
        file = self.cleaned_data.get('file')
        if file:
            # Check file size (max 50MB)
            if file.size > 50 * 1024 * 1024:
                raise ValidationError('File size cannot exceed 50MB.')
            
            # Check file extension
            allowed_extensions = ['.pdf', '.txt', '.jpg', '.jpeg', '.png', '.gif']
            file_ext = '.' + file.name.split('.')[-1].lower()
            if file_ext not in allowed_extensions:
                raise ValidationError('File type not supported. Allowed types: PDF, TXT, Images')
        
        return file
    
    def clean_title(self):
        title = self.cleaned_data.get('title')
        if len(title) < 3:
            raise ValidationError('Title must be at least 3 characters long.')
        return title

class OrganizationAdminRegistrationForm(UserCreationForm):
    """Form for organization admin registration (public)"""
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'First Name'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Last Name'
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Email Address'
        })
    )
    phone = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phone Number'
        })
    )

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'phone', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Username'
        })
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirm Password'
        })

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise ValidationError('A user with this email already exists.')
        return email

class OrganizationSetupForm(forms.ModelForm):
    """Form for setting up organization"""
    class Meta:
        model = Organization
        fields = ['name', 'contact_email', 'contact_phone', 'address', 'logo']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Organization Name'
            }),
            'contact_email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Contact Email'
            }),
            'contact_phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Contact Phone'
            }),
            'address': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Organization Address'
            }),
            'logo': forms.FileInput(attrs={
                'class': 'form-control'
            }),
        }

class AddUserForm(UserCreationForm):
    """Form for organization admins to add trainers and students"""
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'First Name'
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Last Name'
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'form-control',
            'placeholder': 'Email Address'
        })
    )
    role = forms.ChoiceField(
        choices=[('trainer', 'Trainer'), ('student', 'Student')],
        widget=forms.Select(attrs={
            'class': 'form-control'
        })
    )
    phone = forms.CharField(
        max_length=20,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Phone Number'
        })
    )

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'phone', 'role', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Username'
        })
        self.fields['password1'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Password'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'form-control',
            'placeholder': 'Confirm Password'
        })

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise ValidationError('A user with this email already exists.')
        return email