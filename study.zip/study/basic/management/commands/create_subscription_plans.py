from django.core.management.base import BaseCommand
from basic.models import SubscriptionPlan

class Command(BaseCommand):
    help = 'Create default subscription plans'

    def handle(self, *args, **options):
        plans = [
            {
                'name': 'Basic',
                'slug': 'basic',
                'price_monthly': 29.99,
                'price_yearly': 299.99,
                'max_students': 50,
                'max_trainers': 3,
                'max_courses': 10,
                'features': {
                    'qr_attendance': True,
                    'basic_analytics': True,
                    'email_support': True,
                    'storage_gb': 5
                }
            },
            {
                'name': 'Professional',
                'slug': 'professional',
                'price_monthly': 79.99,
                'price_yearly': 799.99,
                'max_students': 200,
                'max_trainers': 10,
                'max_courses': 50,
                'features': {
                    'qr_attendance': True,
                    'advanced_analytics': True,
                    'priority_support': True,
                    'custom_branding': True,
                    'storage_gb': 25,
                    'video_calling': True
                }
            },
            {
                'name': 'Enterprise',
                'slug': 'enterprise',
                'price_monthly': 199.99,
                'price_yearly': 1999.99,
                'max_students': 1000,
                'max_trainers': 50,
                'max_courses': 200,
                'features': {
                    'qr_attendance': True,
                    'advanced_analytics': True,
                    'dedicated_support': True,
                    'custom_branding': True,
                    'custom_domain': True,
                    'storage_gb': 100,
                    'video_calling': True,
                    'api_access': True
                }
            }
        ]

        for plan_data in plans:
            plan, created = SubscriptionPlan.objects.get_or_create(
                slug=plan_data['slug'],
                defaults=plan_data
            )
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Created subscription plan: {plan.name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Subscription plan already exists: {plan.name}')
                )

        self.stdout.write(
            self.style.SUCCESS('Successfully created/updated subscription plans')
        )