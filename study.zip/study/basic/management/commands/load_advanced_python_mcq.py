from django.core.management.base import BaseCommand
from basic.models import Task, MCQQuestion, Course

class Command(BaseCommand):
    help = 'Load Advanced Python MCQ questions into database'

    def add_arguments(self, parser):
        parser.add_argument('--task-id', type=int, help='Task ID to add questions to')
        parser.add_argument('--course-slug', type=str, help='Course slug to find quiz task')

    def handle(self, *args, **options):
        ADVANCED_PYTHON_MCQ_DATA = [
            {
                "question_text": "What is the output of: list(map(lambda x: x**2, filter(lambda x: x%2==0, [1,2,3,4,5])))?",
                "option_a": "[4, 16]",
                "option_b": "[2, 4]",
                "option_c": "[1, 9, 25]",
                "option_d": "[1, 4, 9, 16, 25]",
                "correct_answer": "A",
                "points": 2,
                "order": 1
            },
            {
                "question_text": "Which decorator is used to create a static method in Python?",
                "option_a": "@classmethod",
                "option_b": "@staticmethod",
                "option_c": "@property",
                "option_d": "@method",
                "correct_answer": "B",
                "points": 2,
                "order": 2
            },
            {
                "question_text": "What does the 'yield' keyword do in Python?",
                "option_a": "Returns a value and exits function",
                "option_b": "Creates a generator function",
                "option_c": "Raises an exception",
                "option_d": "Imports a module",
                "correct_answer": "B",
                "points": 2,
                "order": 3
            },
            {
                "question_text": "What is the difference between __str__ and __repr__ methods?",
                "option_a": "No difference",
                "option_b": "__str__ for users, __repr__ for developers",
                "option_c": "__str__ for developers, __repr__ for users",
                "option_d": "Both are same",
                "correct_answer": "B",
                "points": 2,
                "order": 4
            },
            {
                "question_text": "What will be the output of: [x for x in range(10) if x%2==0 if x%3==0]?",
                "option_a": "[0, 6]",
                "option_b": "[0, 2, 4, 6, 8]",
                "option_c": "[0, 3, 6, 9]",
                "option_d": "[6]",
                "correct_answer": "A",
                "points": 2,
                "order": 5
            },
            {
                "question_text": "Which method is used to handle missing keys in a dictionary?",
                "option_a": "get()",
                "option_b": "setdefault()",
                "option_c": "defaultdict()",
                "option_d": "All of the above",
                "correct_answer": "D",
                "points": 2,
                "order": 6
            },
            {
                "question_text": "What is a closure in Python?",
                "option_a": "A way to close files",
                "option_b": "A nested function that captures variables from outer scope",
                "option_c": "A type of loop",
                "option_d": "A class method",
                "correct_answer": "B",
                "points": 3,
                "order": 7
            },
            {
                "question_text": "What does the '*args' parameter do in a function?",
                "option_a": "Accepts keyword arguments",
                "option_b": "Accepts variable number of positional arguments",
                "option_c": "Multiplies arguments",
                "option_d": "Creates a tuple",
                "correct_answer": "B",
                "points": 2,
                "order": 8
            },
            {
                "question_text": "What is the purpose of the 'with' statement in Python?",
                "option_a": "Context management",
                "option_b": "Loop control",
                "option_c": "Exception handling",
                "option_d": "Variable declaration",
                "correct_answer": "A",
                "points": 2,
                "order": 9
            },
            {
                "question_text": "What will 'next(iter([1,2,3]))' return?",
                "option_a": "1",
                "option_b": "2",
                "option_c": "3",
                "option_d": "Error",
                "correct_answer": "A",
                "points": 2,
                "order": 10
            },
            {
                "question_text": "Which of the following is a mutable default argument problem?",
                "option_a": "def func(x=[]): x.append(1); return x",
                "option_b": "def func(x=None): return x or []",
                "option_c": "def func(x=0): return x+1",
                "option_d": "def func(x='hello'): return x",
                "correct_answer": "A",
                "points": 3,
                "order": 11
            },
            {
                "question_text": "What is the Global Interpreter Lock (GIL) in Python?",
                "option_a": "A security feature",
                "option_b": "A mutex that prevents multiple threads from executing Python code simultaneously",
                "option_c": "A type of variable",
                "option_d": "A debugging tool",
                "correct_answer": "B",
                "points": 3,
                "order": 12
            },
            {
                "question_text": "What does the '@property' decorator do?",
                "option_a": "Creates a class property",
                "option_b": "Makes a method behave like an attribute",
                "option_c": "Creates a static method",
                "option_d": "Defines a constructor",
                "correct_answer": "B",
                "points": 2,
                "order": 13
            },
            {
                "question_text": "What is the difference between 'is' and '==' operators?",
                "option_a": "No difference",
                "option_b": "'is' checks identity, '==' checks equality",
                "option_c": "'is' checks equality, '==' checks identity",
                "option_d": "Both check identity",
                "correct_answer": "B",
                "points": 2,
                "order": 14
            },
            {
                "question_text": "What will be the output of: {x: x**2 for x in range(3)}?",
                "option_a": "{0: 0, 1: 1, 2: 4}",
                "option_b": "[0, 1, 4]",
                "option_c": "(0, 1, 4)",
                "option_d": "Error",
                "correct_answer": "A",
                "points": 2,
                "order": 15
            },
            {
                "question_text": "What is monkey patching in Python?",
                "option_a": "A debugging technique",
                "option_b": "Dynamically modifying classes or modules at runtime",
                "option_c": "A type of inheritance",
                "option_d": "Error handling method",
                "correct_answer": "B",
                "points": 3,
                "order": 16
            },
            {
                "question_text": "What does the '__call__' method do?",
                "option_a": "Makes an object callable like a function",
                "option_b": "Calls another method",
                "option_c": "Handles exceptions",
                "option_d": "Creates a new instance",
                "correct_answer": "A",
                "points": 3,
                "order": 17
            },
            {
                "question_text": "What is the purpose of 'super()' function?",
                "option_a": "Creates a superclass",
                "option_b": "Calls parent class methods",
                "option_c": "Makes a class superior",
                "option_d": "Handles inheritance errors",
                "correct_answer": "B",
                "points": 2,
                "order": 18
            },
            {
                "question_text": "What will 'all([True, False, True])' return?",
                "option_a": "True",
                "option_b": "False",
                "option_c": "[True, False, True]",
                "option_d": "Error",
                "correct_answer": "B",
                "points": 2,
                "order": 19
            },
            {
                "question_text": "What is the difference between deepcopy and shallow copy?",
                "option_a": "No difference",
                "option_b": "Deepcopy copies nested objects, shallow copy doesn't",
                "option_c": "Shallow copy is faster",
                "option_d": "Deepcopy is for deep learning",
                "correct_answer": "B",
                "points": 3,
                "order": 20
            },
            {
                "question_text": "What does 'enumerate([10, 20, 30])' return?",
                "option_a": "[(0, 10), (1, 20), (2, 30)]",
                "option_b": "[10, 20, 30]",
                "option_c": "An enumerate object",
                "option_d": "[0, 1, 2]",
                "correct_answer": "C",
                "points": 2,
                "order": 21
            },
            {
                "question_text": "What is a metaclass in Python?",
                "option_a": "A class that creates other classes",
                "option_b": "A parent class",
                "option_c": "A class with metadata",
                "option_d": "An abstract class",
                "correct_answer": "A",
                "points": 3,
                "order": 22
            },
            {
                "question_text": "What does the 'nonlocal' keyword do?",
                "option_a": "Declares a global variable",
                "option_b": "Refers to variables in the nearest enclosing scope",
                "option_c": "Creates a local variable",
                "option_d": "Imports from another module",
                "correct_answer": "B",
                "points": 3,
                "order": 23
            },
            {
                "question_text": "What will 'zip([1,2], [3,4], [5,6])' produce?",
                "option_a": "[(1,3,5), (2,4,6)]",
                "option_b": "[1,2,3,4,5,6]",
                "option_c": "A zip object",
                "option_d": "Error",
                "correct_answer": "C",
                "points": 2,
                "order": 24
            },
            {
                "question_text": "What is the purpose of '__slots__' in a class?",
                "option_a": "Defines available methods",
                "option_b": "Restricts attributes and saves memory",
                "option_c": "Creates time slots",
                "option_d": "Handles inheritance",
                "correct_answer": "B",
                "points": 3,
                "order": 25
            }
        ]

        # Find task
        task = None
        if options['task_id']:
            try:
                task = Task.objects.get(id=options['task_id'])
            except Task.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Task with ID {options["task_id"]} not found'))
                return
        elif options['course_slug']:
            try:
                course = Course.objects.get(slug=options['course_slug'])
                task = course.tasks.filter(task_type='quiz').first()
                if not task:
                    self.stdout.write(self.style.ERROR(f'No quiz task found for course {options["course_slug"]}'))
                    return
            except Course.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Course with slug {options["course_slug"]} not found'))
                return
        else:
            self.stdout.write(self.style.ERROR('Please provide either --task-id or --course-slug'))
            return

        # Delete existing questions for this task
        deleted_count = MCQQuestion.objects.filter(task=task).count()
        MCQQuestion.objects.filter(task=task).delete()
        self.stdout.write(f'Deleted {deleted_count} existing questions')

        # Add new questions
        created_count = 0
        for question_data in ADVANCED_PYTHON_MCQ_DATA:
            MCQQuestion.objects.create(
                task=task,
                question_text=question_data['question_text'],
                option_a=question_data['option_a'],
                option_b=question_data['option_b'],
                option_c=question_data['option_c'],
                option_d=question_data['option_d'],
                correct_answer=question_data['correct_answer'],
                points=question_data['points'],
                order=question_data['order']
            )
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f'Successfully loaded {created_count} Advanced Python MCQ questions for task: {task.title}')
        )