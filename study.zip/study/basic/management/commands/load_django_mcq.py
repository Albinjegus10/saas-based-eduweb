from django.core.management.base import BaseCommand
from basic.models import Task, MCQQuestion, Course

class Command(BaseCommand):
    help = 'Load Django MCQ questions into database'

    def add_arguments(self, parser):
        parser.add_argument('--task-id', type=int, help='Task ID to add questions to')
        parser.add_argument('--course-slug', type=str, help='Course slug to find quiz task')

    def handle(self, *args, **options):
        DJANGO_MCQ_DATA = [
            {
                "question_text": "What is Django?",
                "option_a": "A Python web framework",
                "option_b": "A database",
                "option_c": "A programming language",
                "option_d": "A web server",
                "correct_answer": "A",
                "points": 1,
                "order": 1
            },
            {
                "question_text": "Which command is used to create a new Django project?",
                "option_a": "django-admin createproject",
                "option_b": "django-admin startproject",
                "option_c": "python manage.py startproject",
                "option_d": "python manage.py createproject",
                "correct_answer": "B",
                "points": 1,
                "order": 2
            },
            {
                "question_text": "What is the purpose of models.py in Django?",
                "option_a": "Define URL patterns",
                "option_b": "Define database models",
                "option_c": "Handle HTTP requests",
                "option_d": "Configure settings",
                "correct_answer": "B",
                "points": 1,
                "order": 3
            },
            {
                "question_text": "Which file contains URL patterns in Django?",
                "option_a": "views.py",
                "option_b": "models.py",
                "option_c": "urls.py",
                "option_d": "settings.py",
                "correct_answer": "C",
                "points": 1,
                "order": 4
            },
            {
                "question_text": "What does MVT stand for in Django?",
                "option_a": "Model View Template",
                "option_b": "Model View Type",
                "option_c": "Module View Template",
                "option_d": "Model Variable Template",
                "correct_answer": "A",
                "points": 1,
                "order": 5
            },
            {
                "question_text": "Which command is used to create database tables?",
                "option_a": "python manage.py migrate",
                "option_b": "python manage.py makemigrations",
                "option_c": "python manage.py syncdb",
                "option_d": "python manage.py createdb",
                "correct_answer": "A",
                "points": 1,
                "order": 6
            },
            {
                "question_text": "What is the purpose of makemigrations command?",
                "option_a": "Apply migrations to database",
                "option_b": "Create migration files",
                "option_c": "Delete migrations",
                "option_d": "Show migration status",
                "correct_answer": "B",
                "points": 1,
                "order": 7
            },
            {
                "question_text": "Which decorator is used to require login for a view?",
                "option_a": "@require_login",
                "option_b": "@login_required",
                "option_c": "@authenticate",
                "option_d": "@user_required",
                "correct_answer": "B",
                "points": 2,
                "order": 8
            },
            {
                "question_text": "What is the default database used by Django?",
                "option_a": "MySQL",
                "option_b": "PostgreSQL",
                "option_c": "SQLite",
                "option_d": "MongoDB",
                "correct_answer": "C",
                "points": 1,
                "order": 9
            },
            {
                "question_text": "Which method is used to save a model instance?",
                "option_a": "save()",
                "option_b": "create()",
                "option_c": "insert()",
                "option_d": "add()",
                "correct_answer": "A",
                "points": 1,
                "order": 10
            },
            {
                "question_text": "What is the purpose of Django admin?",
                "option_a": "User authentication",
                "option_b": "Database administration interface",
                "option_c": "URL routing",
                "option_d": "Template rendering",
                "correct_answer": "B",
                "points": 1,
                "order": 11
            },
            {
                "question_text": "Which template tag is used for URL reversing?",
                "option_a": "{% link %}",
                "option_b": "{% url %}",
                "option_c": "{% reverse %}",
                "option_d": "{% path %}",
                "correct_answer": "B",
                "points": 2,
                "order": 12
            },
            {
                "question_text": "What is CSRF protection in Django?",
                "option_a": "Cross-Site Request Forgery protection",
                "option_b": "Cross-Site Resource Forgery protection",
                "option_c": "Client-Side Request Filtering",
                "option_d": "Custom Security Response Framework",
                "correct_answer": "A",
                "points": 2,
                "order": 13
            },
            {
                "question_text": "Which field type is used for storing large text in Django models?",
                "option_a": "CharField",
                "option_b": "TextField",
                "option_c": "TextArea",
                "option_d": "LongText",
                "correct_answer": "B",
                "points": 1,
                "order": 14
            },
            {
                "question_text": "What is the purpose of Django middleware?",
                "option_a": "Handle database connections",
                "option_b": "Process requests and responses globally",
                "option_c": "Manage static files",
                "option_d": "Handle user authentication",
                "correct_answer": "B",
                "points": 2,
                "order": 15
            },
            {
                "question_text": "Which method is used to get a single object from database?",
                "option_a": "get()",
                "option_b": "filter()",
                "option_c": "all()",
                "option_d": "find()",
                "correct_answer": "A",
                "points": 1,
                "order": 16
            },
            {
                "question_text": "What does ForeignKey represent in Django models?",
                "option_a": "Primary key",
                "option_b": "Many-to-one relationship",
                "option_c": "One-to-one relationship",
                "option_d": "Many-to-many relationship",
                "correct_answer": "B",
                "points": 2,
                "order": 17
            },
            {
                "question_text": "Which command creates a superuser in Django?",
                "option_a": "python manage.py createuser",
                "option_b": "python manage.py createsuperuser",
                "option_c": "python manage.py makeuser",
                "option_d": "python manage.py admin",
                "correct_answer": "B",
                "points": 1,
                "order": 18
            },
            {
                "question_text": "What is the purpose of Django forms?",
                "option_a": "Handle HTTP requests",
                "option_b": "Validate and process form data",
                "option_c": "Manage database connections",
                "option_d": "Render templates",
                "correct_answer": "B",
                "points": 2,
                "order": 19
            },
            {
                "question_text": "Which setting controls debug mode in Django?",
                "option_a": "DEBUG_MODE",
                "option_b": "DEBUG",
                "option_c": "DEVELOPMENT",
                "option_d": "DEV_MODE",
                "correct_answer": "B",
                "points": 1,
                "order": 20
            },
            {
                "question_text": "What is the purpose of Django signals?",
                "option_a": "Handle HTTP requests",
                "option_b": "Allow decoupled applications to get notified of actions",
                "option_c": "Manage database transactions",
                "option_d": "Handle user authentication",
                "correct_answer": "B",
                "points": 3,
                "order": 21
            },
            {
                "question_text": "Which method is used to create a new app in Django?",
                "option_a": "django-admin startapp",
                "option_b": "python manage.py startapp",
                "option_c": "Both A and B",
                "option_d": "python manage.py createapp",
                "correct_answer": "C",
                "points": 2,
                "order": 22
            },
            {
                "question_text": "What is the purpose of Django REST framework?",
                "option_a": "Create REST APIs",
                "option_b": "Handle static files",
                "option_c": "Manage user sessions",
                "option_d": "Process forms",
                "correct_answer": "A",
                "points": 2,
                "order": 23
            },
            {
                "question_text": "Which template filter is used to format dates?",
                "option_a": "date",
                "option_b": "format",
                "option_c": "datetime",
                "option_d": "time",
                "correct_answer": "A",
                "points": 2,
                "order": 24
            },
            {
                "question_text": "What is the purpose of Django's ORM?",
                "option_a": "Object Relational Mapping",
                "option_b": "Online Resource Manager",
                "option_c": "Operational Request Manager",
                "option_d": "Object Request Mapper",
                "correct_answer": "A",
                "points": 2,
                "order": 25
            }
        ]

        # Find task
        task = None
        if options['task_id']:
            try:
                task = Task.objects.get(id=options['task_id'])
            except Task.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Task with ID {options["task_id"]} not found'))
                return
        elif options['course_slug']:
            try:
                course = Course.objects.get(slug=options['course_slug'])
                task = course.tasks.filter(task_type='quiz').first()
                if not task:
                    self.stdout.write(self.style.ERROR(f'No quiz task found for course {options["course_slug"]}'))
                    return
            except Course.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Course with slug {options["course_slug"]} not found'))
                return
        else:
            self.stdout.write(self.style.ERROR('Please provide either --task-id or --course-slug'))
            return

        # Delete existing questions for this task
        deleted_count = MCQQuestion.objects.filter(task=task).count()
        MCQQuestion.objects.filter(task=task).delete()
        self.stdout.write(f'Deleted {deleted_count} existing questions')

        # Add new questions
        created_count = 0
        for question_data in DJANGO_MCQ_DATA:
            MCQQuestion.objects.create(
                task=task,
                question_text=question_data['question_text'],
                option_a=question_data['option_a'],
                option_b=question_data['option_b'],
                option_c=question_data['option_c'],
                option_d=question_data['option_d'],
                correct_answer=question_data['correct_answer'],
                points=question_data['points'],
                order=question_data['order']
            )
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f'Successfully loaded {created_count} Django MCQ questions for task: {task.title}')
        )