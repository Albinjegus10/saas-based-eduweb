from django.core.management.base import BaseCommand
from basic.models import Task, MCQQuestion, Course

class Command(BaseCommand):
    help = 'Load Flutter MCQ questions into database'

    def add_arguments(self, parser):
        parser.add_argument('--task-id', type=int, help='Task ID to add questions to')
        parser.add_argument('--course-slug', type=str, help='Course slug to find quiz task')

    def handle(self, *args, **options):
        FLUTTER_MCQ_DATA = [
            {
                "question_text": "What is Flutter?",
                "option_a": "A programming language",
                "option_b": "A mobile app development framework",
                "option_c": "A database",
                "option_d": "A web server",
                "correct_answer": "B",
                "points": 1,
                "order": 1
            },
            {
                "question_text": "Which programming language is used to develop Flutter apps?",
                "option_a": "Java",
                "option_b": "Kotlin",
                "option_c": "Dart",
                "option_d": "Swift",
                "correct_answer": "C",
                "points": 1,
                "order": 2
            },
            {
                "question_text": "What is a Widget in Flutter?",
                "option_a": "A database table",
                "option_b": "A UI component",
                "option_c": "A function",
                "option_d": "A variable",
                "correct_answer": "B",
                "points": 1,
                "order": 3
            },
            {
                "question_text": "Which widget is used for creating a scrollable list?",
                "option_a": "Column",
                "option_b": "Row",
                "option_c": "ListView",
                "option_d": "Container",
                "correct_answer": "C",
                "points": 2,
                "order": 4
            },
            {
                "question_text": "What is the difference between StatelessWidget and StatefulWidget?",
                "option_a": "No difference",
                "option_b": "StatefulWidget can change its state, StatelessWidget cannot",
                "option_c": "StatelessWidget is faster",
                "option_d": "StatefulWidget is for web only",
                "correct_answer": "B",
                "points": 2,
                "order": 5
            },
            {
                "question_text": "Which method is called when a StatefulWidget is first created?",
                "option_a": "build()",
                "option_b": "initState()",
                "option_c": "dispose()",
                "option_d": "setState()",
                "correct_answer": "B",
                "points": 2,
                "order": 6
            },
            {
                "question_text": "What is the purpose of setState() method?",
                "option_a": "Create a new state",
                "option_b": "Delete the current state",
                "option_c": "Notify framework that state has changed",
                "option_d": "Initialize the state",
                "correct_answer": "C",
                "points": 2,
                "order": 7
            },
            {
                "question_text": "Which widget is used for navigation between screens?",
                "option_a": "Navigator",
                "option_b": "Router",
                "option_c": "PageView",
                "option_d": "Scaffold",
                "correct_answer": "A",
                "points": 2,
                "order": 8
            },
            {
                "question_text": "What is the main function in a Flutter app?",
                "option_a": "start()",
                "option_b": "main()",
                "option_c": "run()",
                "option_d": "init()",
                "correct_answer": "B",
                "points": 1,
                "order": 9
            },
            {
                "question_text": "Which widget provides the basic structure for a screen?",
                "option_a": "Container",
                "option_b": "Column",
                "option_c": "Scaffold",
                "option_d": "AppBar",
                "correct_answer": "C",
                "points": 2,
                "order": 10
            },
            {
                "question_text": "What is Hot Reload in Flutter?",
                "option_a": "Restarting the app",
                "option_b": "Quickly updating UI without losing state",
                "option_c": "Debugging feature",
                "option_d": "Performance optimization",
                "correct_answer": "B",
                "points": 2,
                "order": 11
            },
            {
                "question_text": "Which widget is used to display text?",
                "option_a": "Label",
                "option_b": "Text",
                "option_c": "TextView",
                "option_d": "TextWidget",
                "correct_answer": "B",
                "points": 1,
                "order": 12
            },
            {
                "question_text": "What is the purpose of pubspec.yaml file?",
                "option_a": "Define app configuration and dependencies",
                "option_b": "Store user data",
                "option_c": "Handle navigation",
                "option_d": "Manage state",
                "correct_answer": "A",
                "points": 2,
                "order": 13
            },
            {
                "question_text": "Which widget is used for user input?",
                "option_a": "Input",
                "option_b": "TextField",
                "option_c": "EditText",
                "option_d": "TextInput",
                "correct_answer": "B",
                "points": 2,
                "order": 14
            },
            {
                "question_text": "What is the purpose of BuildContext?",
                "option_a": "Build the app",
                "option_b": "Provides location of widget in widget tree",
                "option_c": "Handle user input",
                "option_d": "Manage app state",
                "correct_answer": "B",
                "points": 3,
                "order": 15
            },
            {
                "question_text": "Which layout widget arranges children vertically?",
                "option_a": "Row",
                "option_b": "Column",
                "option_c": "Stack",
                "option_d": "Wrap",
                "correct_answer": "B",
                "points": 1,
                "order": 16
            },
            {
                "question_text": "What is the purpose of MaterialApp widget?",
                "option_a": "Create material design app",
                "option_b": "Handle navigation",
                "option_c": "Manage state",
                "option_d": "Display text",
                "correct_answer": "A",
                "points": 2,
                "order": 17
            },
            {
                "question_text": "Which method is used to navigate to a new screen?",
                "option_a": "Navigator.push()",
                "option_b": "Navigator.go()",
                "option_c": "Navigator.navigate()",
                "option_d": "Navigator.move()",
                "correct_answer": "A",
                "points": 2,
                "order": 18
            },
            {
                "question_text": "What is the purpose of Keys in Flutter?",
                "option_a": "Security",
                "option_b": "Identify widgets uniquely",
                "option_c": "Store data",
                "option_d": "Handle events",
                "correct_answer": "B",
                "points": 3,
                "order": 19
            },
            {
                "question_text": "Which widget is used to handle user gestures?",
                "option_a": "GestureDetector",
                "option_b": "TouchHandler",
                "option_c": "InputHandler",
                "option_d": "EventListener",
                "correct_answer": "A",
                "points": 2,
                "order": 20
            }
        ]

        # Find task
        task = None
        if options['task_id']:
            try:
                task = Task.objects.get(id=options['task_id'])
            except Task.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Task with ID {options["task_id"]} not found'))
                return
        elif options['course_slug']:
            try:
                course = Course.objects.get(slug=options['course_slug'])
                task = course.tasks.filter(task_type='quiz').first()
                if not task:
                    self.stdout.write(self.style.ERROR(f'No quiz task found for course {options["course_slug"]}'))
                    return
            except Course.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Course with slug {options["course_slug"]} not found'))
                return
        else:
            self.stdout.write(self.style.ERROR('Please provide either --task-id or --course-slug'))
            return

        # Delete existing questions for this task
        deleted_count = MCQQuestion.objects.filter(task=task).count()
        MCQQuestion.objects.filter(task=task).delete()
        self.stdout.write(f'Deleted {deleted_count} existing questions')

        # Add new questions
        created_count = 0
        for question_data in FLUTTER_MCQ_DATA:
            MCQQuestion.objects.create(
                task=task,
                question_text=question_data['question_text'],
                option_a=question_data['option_a'],
                option_b=question_data['option_b'],
                option_c=question_data['option_c'],
                option_d=question_data['option_d'],
                correct_answer=question_data['correct_answer'],
                points=question_data['points'],
                order=question_data['order']
            )
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f'Successfully loaded {created_count} Flutter MCQ questions for task: {task.title}')
        )