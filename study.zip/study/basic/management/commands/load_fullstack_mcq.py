from django.core.management.base import BaseCommand
from basic.models import Task, MCQQuestion, Course

class Command(BaseCommand):
    help = 'Load Full Stack MCQ questions into database'

    def add_arguments(self, parser):
        parser.add_argument('--task-id', type=int, help='Task ID to add questions to')
        parser.add_argument('--course-slug', type=str, help='Course slug to find quiz task')

    def handle(self, *args, **options):
        FULLSTACK_MCQ_DATA = [
            {
                "question_text": "What does HTML stand for?",
                "option_a": "Hyper Text Markup Language",
                "option_b": "High Tech Modern Language",
                "option_c": "Home Tool Markup Language",
                "option_d": "Hyperlink and Text Markup Language",
                "correct_answer": "A",
                "points": 1,
                "order": 1
            },
            {
                "question_text": "Which CSS property is used to change the text color?",
                "option_a": "text-color",
                "option_b": "color",
                "option_c": "font-color",
                "option_d": "text-style",
                "correct_answer": "B",
                "points": 1,
                "order": 2
            },
            {
                "question_text": "What is the correct way to declare a JavaScript variable?",
                "option_a": "var myVar;",
                "option_b": "variable myVar;",
                "option_c": "v myVar;",
                "option_d": "declare myVar;",
                "correct_answer": "A",
                "points": 1,
                "order": 3
            },
            {
                "question_text": "Which HTTP method is used to retrieve data from a server?",
                "option_a": "POST",
                "option_b": "PUT",
                "option_c": "GET",
                "option_d": "DELETE",
                "correct_answer": "C",
                "points": 1,
                "order": 4
            },
            {
                "question_text": "What is REST API?",
                "option_a": "Representational State Transfer",
                "option_b": "Remote State Transfer",
                "option_c": "Relational State Transfer",
                "option_d": "Responsive State Transfer",
                "correct_answer": "A",
                "points": 2,
                "order": 5
            },
            {
                "question_text": "Which database is commonly used with Node.js?",
                "option_a": "Oracle",
                "option_b": "MongoDB",
                "option_c": "SQL Server",
                "option_d": "DB2",
                "correct_answer": "B",
                "points": 2,
                "order": 6
            },
            {
                "question_text": "What is the purpose of CSS Grid?",
                "option_a": "Create animations",
                "option_b": "Handle events",
                "option_c": "Create two-dimensional layouts",
                "option_d": "Store data",
                "correct_answer": "C",
                "points": 2,
                "order": 7
            },
            {
                "question_text": "Which JavaScript framework is developed by Facebook?",
                "option_a": "Angular",
                "option_b": "Vue.js",
                "option_c": "React",
                "option_d": "Ember.js",
                "correct_answer": "C",
                "points": 1,
                "order": 8
            },
            {
                "question_text": "What is Node.js?",
                "option_a": "A JavaScript framework",
                "option_b": "A JavaScript runtime environment",
                "option_c": "A database",
                "option_d": "A web browser",
                "correct_answer": "B",
                "points": 2,
                "order": 9
            },
            {
                "question_text": "Which CSS framework is known for responsive design?",
                "option_a": "Bootstrap",
                "option_b": "jQuery",
                "option_c": "Angular",
                "option_d": "React",
                "correct_answer": "A",
                "points": 1,
                "order": 10
            },
            {
                "question_text": "What is the purpose of package.json in Node.js?",
                "option_a": "Store user data",
                "option_b": "Manage project dependencies and metadata",
                "option_c": "Handle routing",
                "option_d": "Create databases",
                "correct_answer": "B",
                "points": 2,
                "order": 11
            },
            {
                "question_text": "Which status code indicates a successful HTTP request?",
                "option_a": "404",
                "option_b": "500",
                "option_c": "200",
                "option_d": "301",
                "correct_answer": "C",
                "points": 1,
                "order": 12
            },
            {
                "question_text": "What is CORS in web development?",
                "option_a": "Cross-Origin Resource Sharing",
                "option_b": "Cross-Origin Request Security",
                "option_c": "Client-Origin Resource Sharing",
                "option_d": "Cross-Object Resource Sharing",
                "correct_answer": "A",
                "points": 2,
                "order": 13
            },
            {
                "question_text": "Which tool is used for version control?",
                "option_a": "npm",
                "option_b": "Git",
                "option_c": "Webpack",
                "option_d": "Babel",
                "correct_answer": "B",
                "points": 1,
                "order": 14
            },
            {
                "question_text": "What is the purpose of Express.js?",
                "option_a": "Frontend framework",
                "option_b": "Database management",
                "option_c": "Web application framework for Node.js",
                "option_d": "CSS preprocessor",
                "correct_answer": "C",
                "points": 2,
                "order": 15
            },
            {
                "question_text": "Which method is used to add an event listener in JavaScript?",
                "option_a": "addEventListener()",
                "option_b": "attachEvent()",
                "option_c": "bindEvent()",
                "option_d": "onEvent()",
                "correct_answer": "A",
                "points": 2,
                "order": 16
            },
            {
                "question_text": "What is JSON?",
                "option_a": "JavaScript Object Notation",
                "option_b": "Java Standard Object Notation",
                "option_c": "JavaScript Oriented Notation",
                "option_d": "Java Script Object Network",
                "correct_answer": "A",
                "points": 1,
                "order": 17
            },
            {
                "question_text": "Which CSS property is used for responsive design?",
                "option_a": "media-query",
                "option_b": "@media",
                "option_c": "responsive",
                "option_d": "breakpoint",
                "correct_answer": "B",
                "points": 2,
                "order": 18
            },
            {
                "question_text": "What is the purpose of Webpack?",
                "option_a": "Database management",
                "option_b": "Module bundler",
                "option_c": "Web server",
                "option_d": "Testing framework",
                "correct_answer": "B",
                "points": 2,
                "order": 19
            },
            {
                "question_text": "Which authentication method uses tokens?",
                "option_a": "Session-based",
                "option_b": "JWT",
                "option_c": "Cookie-based",
                "option_d": "Basic Auth",
                "correct_answer": "B",
                "points": 2,
                "order": 20
            },
            {
                "question_text": "What is the purpose of middleware in Express.js?",
                "option_a": "Handle database connections",
                "option_b": "Process requests between client and server",
                "option_c": "Create user interfaces",
                "option_d": "Manage file uploads",
                "correct_answer": "B",
                "points": 3,
                "order": 21
            },
            {
                "question_text": "Which CSS preprocessor is most popular?",
                "option_a": "SASS",
                "option_b": "LESS",
                "option_c": "Stylus",
                "option_d": "PostCSS",
                "correct_answer": "A",
                "points": 2,
                "order": 22
            },
            {
                "question_text": "What is the Virtual DOM in React?",
                "option_a": "A real DOM element",
                "option_b": "A JavaScript representation of the real DOM",
                "option_c": "A database table",
                "option_d": "A server component",
                "correct_answer": "B",
                "points": 3,
                "order": 23
            },
            {
                "question_text": "Which database operation is NOT part of CRUD?",
                "option_a": "Create",
                "option_b": "Read",
                "option_c": "Update",
                "option_d": "Connect",
                "correct_answer": "D",
                "points": 2,
                "order": 24
            },
            {
                "question_text": "What is the purpose of Docker in development?",
                "option_a": "Code editing",
                "option_b": "Containerization",
                "option_c": "Database management",
                "option_d": "Version control",
                "correct_answer": "B",
                "points": 3,
                "order": 25
            },
            {
                "question_text": "Which testing framework is popular for JavaScript?",
                "option_a": "Jest",
                "option_b": "PHPUnit",
                "option_c": "NUnit",
                "option_d": "JUnit",
                "correct_answer": "A",
                "points": 2,
                "order": 26
            },
            {
                "question_text": "What is GraphQL?",
                "option_a": "A database",
                "option_b": "A query language for APIs",
                "option_c": "A web framework",
                "option_d": "A CSS library",
                "correct_answer": "B",
                "points": 3,
                "order": 27
            },
            {
                "question_text": "Which deployment platform is popular for web applications?",
                "option_a": "Heroku",
                "option_b": "Photoshop",
                "option_c": "Excel",
                "option_d": "PowerPoint",
                "correct_answer": "A",
                "points": 2,
                "order": 28
            },
            {
                "question_text": "What is the purpose of Redux in React applications?",
                "option_a": "Styling components",
                "option_b": "State management",
                "option_c": "Routing",
                "option_d": "API calls",
                "correct_answer": "B",
                "points": 3,
                "order": 29
            },
            {
                "question_text": "Which protocol is used for real-time communication?",
                "option_a": "HTTP",
                "option_b": "FTP",
                "option_c": "WebSocket",
                "option_d": "SMTP",
                "correct_answer": "C",
                "points": 3,
                "order": 30
            }
        ]

        # Find task
        task = None
        if options['task_id']:
            try:
                task = Task.objects.get(id=options['task_id'])
            except Task.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Task with ID {options["task_id"]} not found'))
                return
        elif options['course_slug']:
            try:
                course = Course.objects.get(slug=options['course_slug'])
                task = course.tasks.filter(task_type='quiz').first()
                if not task:
                    self.stdout.write(self.style.ERROR(f'No quiz task found for course {options["course_slug"]}'))
                    return
            except Course.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Course with slug {options["course_slug"]} not found'))
                return
        else:
            self.stdout.write(self.style.ERROR('Please provide either --task-id or --course-slug'))
            return

        # Delete existing questions for this task
        deleted_count = MCQQuestion.objects.filter(task=task).count()
        MCQQuestion.objects.filter(task=task).delete()
        self.stdout.write(f'Deleted {deleted_count} existing questions')

        # Add new questions
        created_count = 0
        for question_data in FULLSTACK_MCQ_DATA:
            MCQQuestion.objects.create(
                task=task,
                question_text=question_data['question_text'],
                option_a=question_data['option_a'],
                option_b=question_data['option_b'],
                option_c=question_data['option_c'],
                option_d=question_data['option_d'],
                correct_answer=question_data['correct_answer'],
                points=question_data['points'],
                order=question_data['order']
            )
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f'Successfully loaded {created_count} Full Stack MCQ questions for task: {task.title}')
        )