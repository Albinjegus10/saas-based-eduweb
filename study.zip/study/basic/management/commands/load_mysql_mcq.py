from django.core.management.base import BaseCommand
from basic.models import Task, MCQQuestion, Course

class Command(BaseCommand):
    help = 'Load MySQL MCQ questions into database'

    def add_arguments(self, parser):
        parser.add_argument('--task-id', type=int, help='Task ID to add questions to')
        parser.add_argument('--course-slug', type=str, help='Course slug to find quiz task')

    def handle(self, *args, **options):
        MYSQL_MCQ_DATA = [
            {
                "question_text": "What does SQL stand for?",
                "option_a": "Structured Query Language",
                "option_b": "Simple Query Language",
                "option_c": "Standard Query Language",
                "option_d": "System Query Language",
                "correct_answer": "A",
                "points": 1,
                "order": 1
            },
            {
                "question_text": "Which command is used to create a new database in MySQL?",
                "option_a": "CREATE DB",
                "option_b": "CREATE DATABASE",
                "option_c": "NEW DATABASE",
                "option_d": "MAKE DATABASE",
                "correct_answer": "B",
                "points": 1,
                "order": 2
            },
            {
                "question_text": "Which data type is used to store large text in MySQL?",
                "option_a": "VARCHAR",
                "option_b": "CHAR",
                "option_c": "TEXT",
                "option_d": "STRING",
                "correct_answer": "C",
                "points": 1,
                "order": 3
            },
            {
                "question_text": "What is the default port number for MySQL?",
                "option_a": "3306",
                "option_b": "3307",
                "option_c": "8080",
                "option_d": "5432",
                "correct_answer": "A",
                "points": 1,
                "order": 4
            },
            {
                "question_text": "Which command is used to select all columns from a table?",
                "option_a": "SELECT ALL FROM table",
                "option_b": "SELECT * FROM table",
                "option_c": "GET * FROM table",
                "option_d": "FETCH * FROM table",
                "correct_answer": "B",
                "points": 1,
                "order": 5
            },
            {
                "question_text": "What is a PRIMARY KEY in MySQL?",
                "option_a": "A key that can be null",
                "option_b": "A unique identifier for each row",
                "option_c": "A foreign reference",
                "option_d": "An index key",
                "correct_answer": "B",
                "points": 2,
                "order": 6
            },
            {
                "question_text": "Which clause is used to filter records in MySQL?",
                "option_a": "FILTER",
                "option_b": "WHERE",
                "option_c": "HAVING",
                "option_d": "CONDITION",
                "correct_answer": "B",
                "points": 1,
                "order": 7
            },
            {
                "question_text": "What does the AUTO_INCREMENT attribute do?",
                "option_a": "Automatically increases table size",
                "option_b": "Automatically generates unique numbers",
                "option_c": "Increases query speed",
                "option_d": "Increments all values",
                "correct_answer": "B",
                "points": 2,
                "order": 8
            },
            {
                "question_text": "Which command is used to add a new column to an existing table?",
                "option_a": "ADD COLUMN",
                "option_b": "ALTER TABLE ADD",
                "option_c": "INSERT COLUMN",
                "option_d": "CREATE COLUMN",
                "correct_answer": "B",
                "points": 2,
                "order": 9
            },
            {
                "question_text": "What is the purpose of the JOIN clause?",
                "option_a": "Combine rows from multiple tables",
                "option_b": "Join two databases",
                "option_c": "Connect to server",
                "option_d": "Merge columns",
                "correct_answer": "A",
                "points": 2,
                "order": 10
            },
            {
                "question_text": "Which type of JOIN returns all records from both tables?",
                "option_a": "INNER JOIN",
                "option_b": "LEFT JOIN",
                "option_c": "RIGHT JOIN",
                "option_d": "FULL OUTER JOIN",
                "correct_answer": "D",
                "points": 2,
                "order": 11
            },
            {
                "question_text": "What does the GROUP BY clause do?",
                "option_a": "Groups related records together",
                "option_b": "Groups databases",
                "option_c": "Groups users",
                "option_d": "Groups servers",
                "correct_answer": "A",
                "points": 2,
                "order": 12
            },
            {
                "question_text": "Which function is used to count the number of rows?",
                "option_a": "COUNT()",
                "option_b": "SUM()",
                "option_c": "TOTAL()",
                "option_d": "NUMBER()",
                "correct_answer": "A",
                "points": 1,
                "order": 13
            },
            {
                "question_text": "What is the difference between DELETE and TRUNCATE?",
                "option_a": "No difference",
                "option_b": "DELETE removes specific rows, TRUNCATE removes all rows",
                "option_c": "TRUNCATE is slower",
                "option_d": "DELETE removes table structure",
                "correct_answer": "B",
                "points": 3,
                "order": 14
            },
            {
                "question_text": "Which constraint ensures that a column cannot have NULL values?",
                "option_a": "UNIQUE",
                "option_b": "PRIMARY KEY",
                "option_c": "NOT NULL",
                "option_d": "CHECK",
                "correct_answer": "C",
                "points": 2,
                "order": 15
            },
            {
                "question_text": "What is an INDEX in MySQL?",
                "option_a": "A table reference",
                "option_b": "A data structure that improves query performance",
                "option_c": "A backup file",
                "option_d": "A user permission",
                "correct_answer": "B",
                "points": 2,
                "order": 16
            },
            {
                "question_text": "Which command is used to remove a table from database?",
                "option_a": "DELETE TABLE",
                "option_b": "REMOVE TABLE",
                "option_c": "DROP TABLE",
                "option_d": "CLEAR TABLE",
                "correct_answer": "C",
                "points": 1,
                "order": 17
            },
            {
                "question_text": "What does FOREIGN KEY constraint do?",
                "option_a": "Creates a unique key",
                "option_b": "Links two tables together",
                "option_c": "Encrypts data",
                "option_d": "Indexes the table",
                "correct_answer": "B",
                "points": 2,
                "order": 18
            },
            {
                "question_text": "Which clause is used to sort the result set?",
                "option_a": "SORT BY",
                "option_b": "ORDER BY",
                "option_c": "ARRANGE BY",
                "option_d": "GROUP BY",
                "correct_answer": "B",
                "points": 1,
                "order": 19
            },
            {
                "question_text": "What is the maximum length of VARCHAR in MySQL?",
                "option_a": "255 characters",
                "option_b": "65535 characters",
                "option_c": "1024 characters",
                "option_d": "Unlimited",
                "correct_answer": "B",
                "points": 2,
                "order": 20
            },
            {
                "question_text": "Which function returns the current date and time?",
                "option_a": "CURRENT_TIME()",
                "option_b": "NOW()",
                "option_c": "TODAY()",
                "option_d": "DATETIME()",
                "correct_answer": "B",
                "points": 2,
                "order": 21
            },
            {
                "question_text": "What is a VIEW in MySQL?",
                "option_a": "A physical table",
                "option_b": "A virtual table based on SQL query",
                "option_c": "A backup copy",
                "option_d": "A user interface",
                "correct_answer": "B",
                "points": 3,
                "order": 22
            },
            {
                "question_text": "Which storage engine is default in MySQL?",
                "option_a": "MyISAM",
                "option_b": "InnoDB",
                "option_c": "Memory",
                "option_d": "Archive",
                "correct_answer": "B",
                "points": 2,
                "order": 23
            },
            {
                "question_text": "What does the LIMIT clause do?",
                "option_a": "Limits database size",
                "option_b": "Limits number of returned rows",
                "option_c": "Limits user access",
                "option_d": "Limits query time",
                "correct_answer": "B",
                "points": 2,
                "order": 24
            },
            {
                "question_text": "Which command is used to create a backup of MySQL database?",
                "option_a": "BACKUP DATABASE",
                "option_b": "mysqldump",
                "option_c": "EXPORT DATABASE",
                "option_d": "SAVE DATABASE",
                "correct_answer": "B",
                "points": 2,
                "order": 25
            }
        ]

        # Find task
        task = None
        if options['task_id']:
            try:
                task = Task.objects.get(id=options['task_id'])
            except Task.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Task with ID {options["task_id"]} not found'))
                return
        elif options['course_slug']:
            try:
                course = Course.objects.get(slug=options['course_slug'])
                task = course.tasks.filter(task_type='quiz').first()
                if not task:
                    self.stdout.write(self.style.ERROR(f'No quiz task found for course {options["course_slug"]}'))
                    return
            except Course.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Course with slug {options["course_slug"]} not found'))
                return
        else:
            self.stdout.write(self.style.ERROR('Please provide either --task-id or --course-slug'))
            return

        # Delete existing questions for this task
        deleted_count = MCQQuestion.objects.filter(task=task).count()
        MCQQuestion.objects.filter(task=task).delete()
        self.stdout.write(f'Deleted {deleted_count} existing questions')

        # Add new questions
        created_count = 0
        for question_data in MYSQL_MCQ_DATA:
            MCQQuestion.objects.create(
                task=task,
                question_text=question_data['question_text'],
                option_a=question_data['option_a'],
                option_b=question_data['option_b'],
                option_c=question_data['option_c'],
                option_d=question_data['option_d'],
                correct_answer=question_data['correct_answer'],
                points=question_data['points'],
                order=question_data['order']
            )
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f'Successfully loaded {created_count} MySQL MCQ questions for task: {task.title}')
        )