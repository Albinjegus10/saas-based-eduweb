from django.core.management.base import BaseCommand
from basic.models import Task, MCQQuestion, Course

class Command(BaseCommand):
    help = 'Load Python MCQ questions into database'

    def add_arguments(self, parser):
        parser.add_argument('--task-id', type=int, help='Task ID to add questions to')
        parser.add_argument('--course-slug', type=str, help='Course slug to find quiz task')

    def handle(self, *args, **options):
        PYTHON_MCQ_DATA = [
            {
                "question_text": "What is the correct way to create a variable in Python?",
                "option_a": "var x = 5",
                "option_b": "x = 5", 
                "option_c": "int x = 5",
                "option_d": "variable x = 5",
                "correct_answer": "B",
                "points": 1,
                "order": 1
            },
            {
                "question_text": "Which of the following is NOT a valid Python data type?",
                "option_a": "int",
                "option_b": "float",
                "option_c": "char",
                "option_d": "str",
                "correct_answer": "C",
                "points": 1,
                "order": 2
            },
            {
                "question_text": "What will be the output of: print(type(5.0))?",
                "option_a": "<class 'int'>",
                "option_b": "<class 'float'>",
                "option_c": "<class 'double'>",
                "option_d": "<class 'number'>",
                "correct_answer": "B",
                "points": 1,
                "order": 3
            },
            {
                "question_text": "Which operator is used for exponentiation in Python?",
                "option_a": "^",
                "option_b": "**",
                "option_c": "pow",
                "option_d": "exp",
                "correct_answer": "B",
                "points": 1,
                "order": 4
            },
            {
                "question_text": "What is the correct way to create a list in Python?",
                "option_a": "list = {1, 2, 3}",
                "option_b": "list = (1, 2, 3)",
                "option_c": "list = [1, 2, 3]",
                "option_d": "list = <1, 2, 3>",
                "correct_answer": "C",
                "points": 1,
                "order": 5
            },
            {
                "question_text": "Which method is used to add an element to the end of a list?",
                "option_a": "add()",
                "option_b": "append()",
                "option_c": "insert()",
                "option_d": "push()",
                "correct_answer": "B",
                "points": 1,
                "order": 6
            },
            {
                "question_text": "What will len('Python') return?",
                "option_a": "5",
                "option_b": "6",
                "option_c": "7",
                "option_d": "Error",
                "correct_answer": "B",
                "points": 1,
                "order": 7
            },
            {
                "question_text": "Which of the following is used to define a function in Python?",
                "option_a": "function",
                "option_b": "def",
                "option_c": "define",
                "option_d": "fun",
                "correct_answer": "B",
                "points": 1,
                "order": 8
            },
            {
                "question_text": "What is the correct way to create a dictionary in Python?",
                "option_a": "dict = {key: value}",
                "option_b": "dict = (key: value)",
                "option_c": "dict = [key: value]",
                "option_d": "dict = <key: value>",
                "correct_answer": "A",
                "points": 1,
                "order": 9
            },
            {
                "question_text": "Which loop is used to iterate over a sequence in Python?",
                "option_a": "while",
                "option_b": "for",
                "option_c": "loop",
                "option_d": "repeat",
                "correct_answer": "B",
                "points": 1,
                "order": 10
            },
            {
                "question_text": "What does the 'break' statement do in a loop?",
                "option_a": "Pauses the loop",
                "option_b": "Exits the loop",
                "option_c": "Restarts the loop",
                "option_d": "Skips current iteration",
                "correct_answer": "B",
                "points": 1,
                "order": 11
            },
            {
                "question_text": "Which method converts a string to lowercase?",
                "option_a": "lower()",
                "option_b": "lowercase()",
                "option_c": "toLower()",
                "option_d": "downcase()",
                "correct_answer": "A",
                "points": 1,
                "order": 12
            },
            {
                "question_text": "What will 10 // 3 return in Python?",
                "option_a": "3.33",
                "option_b": "3",
                "option_c": "4",
                "option_d": "3.0",
                "correct_answer": "B",
                "points": 1,
                "order": 13
            },
            {
                "question_text": "Which of the following is a mutable data type?",
                "option_a": "tuple",
                "option_b": "string",
                "option_c": "list",
                "option_d": "int",
                "correct_answer": "C",
                "points": 1,
                "order": 14
            },
            {
                "question_text": "What is the correct way to import a module in Python?",
                "option_a": "include module_name",
                "option_b": "import module_name",
                "option_c": "using module_name",
                "option_d": "require module_name",
                "correct_answer": "B",
                "points": 1,
                "order": 15
            },
            {
                "question_text": "Which function is used to get user input in Python 3?",
                "option_a": "input()",
                "option_b": "raw_input()",
                "option_c": "get_input()",
                "option_d": "read()",
                "correct_answer": "A",
                "points": 1,
                "order": 16
            },
            {
                "question_text": "What does the 'pass' statement do?",
                "option_a": "Exits the program",
                "option_b": "Does nothing",
                "option_c": "Raises an error",
                "option_d": "Skips to next line",
                "correct_answer": "B",
                "points": 1,
                "order": 17
            },
            {
                "question_text": "Which of the following is correct syntax for exception handling?",
                "option_a": "try-catch",
                "option_b": "try-except",
                "option_c": "catch-try",
                "option_d": "handle-error",
                "correct_answer": "B",
                "points": 1,
                "order": 18
            },
            {
                "question_text": "What will bool([]) return?",
                "option_a": "True",
                "option_b": "False",
                "option_c": "Error",
                "option_d": "None",
                "correct_answer": "B",
                "points": 1,
                "order": 19
            },
            {
                "question_text": "Which method is used to remove whitespace from both ends of a string?",
                "option_a": "trim()",
                "option_b": "strip()",
                "option_c": "clean()",
                "option_d": "remove()",
                "correct_answer": "B",
                "points": 1,
                "order": 20
            },
            {
                "question_text": "What is the correct way to create a tuple with one element?",
                "option_a": "tuple = (1)",
                "option_b": "tuple = (1,)",
                "option_c": "tuple = [1]",
                "option_d": "tuple = {1}",
                "correct_answer": "B",
                "points": 2,
                "order": 21
            },
            {
                "question_text": "Which of the following will create a set in Python?",
                "option_a": "set = [1, 2, 3]",
                "option_b": "set = (1, 2, 3)",
                "option_c": "set = {1, 2, 3}",
                "option_d": "set = <1, 2, 3>",
                "correct_answer": "C",
                "points": 2,
                "order": 22
            },
            {
                "question_text": "What does the 'continue' statement do in a loop?",
                "option_a": "Exits the loop",
                "option_b": "Pauses the loop",
                "option_c": "Skips the current iteration",
                "option_d": "Restarts the loop",
                "correct_answer": "C",
                "points": 2,
                "order": 23
            },
            {
                "question_text": "Which operator is used for membership testing?",
                "option_a": "is",
                "option_b": "in",
                "option_c": "has",
                "option_d": "contains",
                "correct_answer": "B",
                "points": 2,
                "order": 24
            },
            {
                "question_text": "What will 'Hello' * 3 return?",
                "option_a": "Hello3",
                "option_b": "HelloHelloHello",
                "option_c": "Hello Hello Hello",
                "option_d": "Error",
                "correct_answer": "B",
                "points": 2,
                "order": 25
            }
        ]

        # Find task
        task = None
        if options['task_id']:
            try:
                task = Task.objects.get(id=options['task_id'])
            except Task.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Task with ID {options["task_id"]} not found'))
                return
        elif options['course_slug']:
            try:
                course = Course.objects.get(slug=options['course_slug'])
                task = course.tasks.filter(task_type='quiz').first()
                if not task:
                    self.stdout.write(self.style.ERROR(f'No quiz task found for course {options["course_slug"]}'))
                    return
            except Course.DoesNotExist:
                self.stdout.write(self.style.ERROR(f'Course with slug {options["course_slug"]} not found'))
                return
        else:
            self.stdout.write(self.style.ERROR('Please provide either --task-id or --course-slug'))
            return

        # Delete existing questions for this task
        deleted_count = MCQQuestion.objects.filter(task=task).count()
        MCQQuestion.objects.filter(task=task).delete()
        self.stdout.write(f'Deleted {deleted_count} existing questions')

        # Add new questions
        created_count = 0
        for question_data in PYTHON_MCQ_DATA:
            MCQQuestion.objects.create(
                task=task,
                question_text=question_data['question_text'],
                option_a=question_data['option_a'],
                option_b=question_data['option_b'],
                option_c=question_data['option_c'],
                option_d=question_data['option_d'],
                correct_answer=question_data['correct_answer'],
                points=question_data['points'],
                order=question_data['order']
            )
            created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f'Successfully loaded {created_count} Python MCQ questions for task: {task.title}')
        )