from django.db import models
from django.db.models import QuerySet

class TenantQuerySet(QuerySet):
    """
    Custom QuerySet that filters by organization
    """
    
    def for_tenant(self, organization):
        """Filter queryset by organization"""
        return self.filter(organization=organization)

class TenantManager(models.Manager):
    """
    Custom manager for tenant-aware models
    """
    
    def get_queryset(self):
        return TenantQuerySet(self.model, using=self._db)
    
    def for_tenant(self, organization):
        """Get objects for specific organization"""
        return self.get_queryset().for_tenant(organization)

class TenantAwareModel(models.Model):
    """
    Abstract base model for tenant-aware models
    """
    
    objects = TenantManager()
    
    class Meta:
        abstract = True
    
    def save(self, *args, **kwargs):
        # Auto-set organization from current context if available
        if not hasattr(self, 'organization') or not self.organization:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            # This would be set by the view or form
            pass
        super().save(*args, **kwargs)