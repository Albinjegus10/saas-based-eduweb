from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import redirect
from django.contrib import messages

class TenantMiddleware(MiddlewareMixin):
    """
    Middleware to handle multi-tenant functionality
    """
    
    def process_request(self, request):
        # Skip for admin, static files, and auth URLs
        if (request.path.startswith('/admin/') or 
            request.path.startswith('/static/') or 
            request.path.startswith('/media/') or
            request.path.startswith('/accounts/') or
            request.path.startswith('/superadmin/')):
            return None
        
        # Set tenant context for authenticated users
        if request.user.is_authenticated:
            # Superuser has full access - no tenant restrictions
            if request.user.is_superuser:
                return None
                
            if hasattr(request.user, 'organization') and request.user.organization:
                request.tenant = request.user.organization
            else:
                # User has no organization - redirect to setup
                if not request.path.startswith('/setup-organization/'):
                    messages.warning(request, 'Please set up your organization first.')
                    return redirect('setup_organization')
        
        return None

class TenantQuerySetMixin:
    """
    Mixin to automatically filter querysets by tenant
    """
    
    def get_queryset(self):
        queryset = super().get_queryset()
        if hasattr(self.request, 'tenant') and hasattr(queryset.model, 'organization'):
            return queryset.filter(organization=self.request.tenant)
        return queryset