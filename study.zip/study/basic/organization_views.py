from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import User, Trainer
from .forms import UserRegistrationForm

@login_required
def add_user_to_organization(request):
    """Organization admin can add trainers and students"""
    if request.user.role != 'admin' or not request.user.organization:
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.organization = request.user.organization
            user.is_active = True  # Organization admin can directly activate
            user.save()
            
            # Create trainer profile if needed
            if user.role == 'trainer':
                Trainer.objects.create(
                    user=user,
                    expertise='',
                    bio='Please update your profile.',
                )
            
            # Send welcome email
            try:
                send_mail(
                    subject=f'Welcome to {request.user.organization.name}',
                    message=f'''
Hello {user.get_full_name()},

You have been added to {request.user.organization.name} as a {user.get_role_display()}.

Login details:
- Email: {user.email}
- Temporary Password: Please contact your admin

Please login and update your profile.

Best regards,
{request.user.organization.name}
                    ''',
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[user.email],
                    fail_silently=True,
                )
            except:
                pass
            
            messages.success(request, f'{user.get_role_display()} {user.get_full_name()} added successfully!')
            return redirect('admin_dashboard')
    else:
        form = UserRegistrationForm()
        # Remove admin option for organization admins
        form.fields['role'].choices = [
            ('trainer', 'Trainer'),
            ('student', 'Student'),
        ]
    
    return render(request, 'organization/add_user.html', {'form': form})