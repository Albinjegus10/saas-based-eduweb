import requests
import json
from django.conf import settings
from django.core.cache import cache
from django.db.models import Q
from .models import Message, User, Course
import logging

logger = logging.getLogger(__name__)

class WhatsAppService:
    def __init__(self):
        self.api_url = settings.WHATSAPP_API_URL
        self.access_token = settings.WHATSAPP_ACCESS_TOKEN
        self.phone_number_id = settings.WHATSAPP_PHONE_NUMBER_ID
        
    def send_message(self, to_number, message_text, message_type='text'):
        """Send WhatsApp message"""
        url = f"{self.api_url}/{self.phone_number_id}/messages"
        
        headers = {
            'Authorization': f'Bearer {self.access_token}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'messaging_product': 'whatsapp',
            'to': to_number,
            'type': message_type,
            'text': {
                'body': message_text
            }
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"WhatsApp API error: {e}")
            return None
    
    def send_course_notification(self, user, course, message):
        """Send course-related notification via WhatsApp"""
        if hasattr(user, 'preferences') and user.preferences.whatsapp_notifications:
            whatsapp_number = user.preferences.whatsapp_number
            if whatsapp_number:
                full_message = f"📚 {course.title}\n\n{message}"
                return self.send_message(whatsapp_number, full_message)
        return None
    
    def send_assignment_reminder(self, user, task):
        """Send assignment reminder"""
        message = f"⏰ Reminder: Assignment '{task.title}' is due soon!\n\nDue: {task.due_date}\nPoints: {task.points}"
        return self.send_course_notification(user, task.course, message)

class CacheService:
    """Redis caching service"""
    
    @staticmethod
    def get_course_stats(course_id):
        """Get cached course statistics"""
        cache_key = f"course_stats_{course_id}"
        stats = cache.get(cache_key)
        
        if not stats:
            from .models import Course, Enrollment
            course = Course.objects.get(id=course_id)
            stats = {
                'enrolled_count': course.enrolled_count,
                'completion_rate': 0,  # Calculate based on your logic
                'average_progress': 0,  # Calculate based on your logic
            }
            cache.set(cache_key, stats, 300)  # Cache for 5 minutes
        
        return stats
    
    @staticmethod
    def invalidate_course_cache(course_id):
        """Invalidate course-related cache"""
        cache_keys = [
            f"course_stats_{course_id}",
            f"course_students_{course_id}",
            f"course_forum_{course_id}"
        ]
        cache.delete_many(cache_keys)
    
    @staticmethod
    def get_user_conversations(user_id):
        """Get cached user conversations"""
        cache_key = f"user_conversations_{user_id}"
        conversations = cache.get(cache_key)
        
        if not conversations:
            from .models import Conversation
            conversations = list(
                Conversation.objects.filter(participants=user_id)
                .select_related('last_message', 'course')
                .prefetch_related('participants')
                .values(
                    'id', 'course__title', 'last_message__content',
                    'last_message__created_at', 'updated_at'
                )[:20]
            )
            cache.set(cache_key, conversations, 60)  # Cache for 1 minute
        
        return conversations

class DatabaseOptimizationService:
    """Database optimization utilities"""
    
    @staticmethod
    def get_optimized_courses():
        """Get courses with optimized queries"""
        return Course.objects.select_related(
            'trainer__user', 'category'
        ).prefetch_related(
            'enrollments__user'
        ).annotate(
            enrolled_count=models.Count('enrollments')
        )
    
    @staticmethod
    def get_optimized_forum_topics(course_id):
        """Get forum topics with optimized queries"""
        return ForumTopic.objects.filter(
            category__course_id=course_id
        ).select_related(
            'author', 'category'
        ).prefetch_related(
            'replies__author'
        ).annotate(
            reply_count=models.Count('replies')
        )

class NotificationService:
    """Unified notification service"""
    
    def __init__(self):
        self.whatsapp = WhatsAppService()
    
    def notify_new_enrollment(self, enrollment):
        """Notify trainer about new enrollment"""
        trainer = enrollment.course.trainer.user
        message = f"🎉 New student enrolled!\n\n{enrollment.user.get_full_name()} has enrolled in your course."
        
        # Send WhatsApp notification
        self.whatsapp.send_course_notification(trainer, enrollment.course, message)
        
        # Create in-app message
        Message.objects.create(
            sender=enrollment.user,
            recipient=trainer,
            course=enrollment.course,
            content=f"I've enrolled in your course: {enrollment.course.title}",
            message_type='text'
        )
    
    def notify_assignment_submission(self, submission):
        """Notify trainer about assignment submission"""
        trainer = submission.task.course.trainer.user
        message = f"📝 New submission received!\n\n{submission.user.get_full_name()} submitted: {submission.task.title}"
        
        self.whatsapp.send_course_notification(trainer, submission.task.course, message)
    
    def notify_forum_reply(self, reply):
        """Notify topic author about new reply"""
        if reply.author != reply.topic.author:
            message = f"💬 New reply to your topic!\n\n'{reply.topic.title}' has a new reply from {reply.author.get_full_name()}"
            self.whatsapp.send_course_notification(
                reply.topic.author, 
                reply.topic.category.course, 
                message
            )