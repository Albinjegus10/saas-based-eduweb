from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import User, Organization, Subscription, SubscriptionPlan
from datetime import datetime, timedelta

def is_superuser(user):
    return user.is_superuser

@login_required
@user_passes_test(is_superuser)
def superadmin_dashboard(request):
    """SuperAdmin dashboard to manage organizations"""
    context = {
        'pending_users': User.objects.filter(is_active=False, role='admin'),
        'total_organizations': Organization.objects.count(),
        'active_subscriptions': Subscription.objects.filter(status__in=['active', 'trial']).count(),
        'total_revenue': 0,  # Calculate from payments
        'recent_organizations': Organization.objects.order_by('-created_at')[:5],
    }
    return render(request, 'superadmin/dashboard.html', context)

@login_required
@user_passes_test(is_superuser)
def approve_organization_admin(request, user_id):
    """Approve organization admin and allow them to create organization"""
    user = get_object_or_404(User, id=user_id, role='admin', is_active=False)
    
    user.is_active = True
    user.is_staff = True  # Allow access to Django admin
    user.save()
    
    # Send approval email
    try:
        send_mail(
            subject='Your Organization Account Approved',
            message=f'''
Hello {user.get_full_name()},

Your organization admin account has been approved!

You can now login and set up your organization:
- Login: {request.build_absolute_uri('/login/')}
- Set up your organization details
- Start your 14-day free trial

Best regards,
{settings.DEFAULT_FROM_EMAIL}
            ''',
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email],
            fail_silently=True,
        )
    except:
        pass
    
    messages.success(request, f'Organization admin {user.get_full_name()} approved!')
    return redirect('superadmin_dashboard')

@login_required
@user_passes_test(is_superuser)
def reject_organization_admin(request, user_id):
    """Reject organization admin request"""
    user = get_object_or_404(User, id=user_id, role='admin', is_active=False)
    
    # Send rejection email
    try:
        send_mail(
            subject='Organization Account Request',
            message=f'''
Hello {user.get_full_name()},

Thank you for your interest in our platform. Unfortunately, we cannot approve your organization account at this time.

If you have any questions, please contact us.

Best regards,
{settings.DEFAULT_FROM_EMAIL}
            ''',
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email],
            fail_silently=True,
        )
    except:
        pass
    
    user.delete()
    messages.success(request, 'Organization admin request rejected!')
    return redirect('superadmin_dashboard')