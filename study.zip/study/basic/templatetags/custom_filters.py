from django import template

register = template.Library()

@register.filter
def lookup(d, key):
    """Custom filter to lookup dictionary values by key"""
    return d.get(key)