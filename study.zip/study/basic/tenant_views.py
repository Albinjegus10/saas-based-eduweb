from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.generic import CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Organization, SubscriptionPlan, Subscription
from .forms import OrganizationSetupForm
from datetime import datetime, timedelta

@login_required
def setup_organization(request):
    """Setup organization for new users"""
    if request.user.organization:
        return redirect('home')
    
    if request.method == 'POST':
        form = OrganizationSetupForm(request.POST, request.FILES)
        if form.is_valid():
            organization = form.save()
            
            # Assign user to organization
            request.user.organization = organization
            request.user.role = 'admin'  # First user becomes admin
            request.user.save()
            
            # Create trial subscription
            try:
                basic_plan = SubscriptionPlan.objects.get(slug='basic')
                Subscription.objects.create(
                    organization=organization,
                    plan=basic_plan,
                    status='trial',
                    end_date=datetime.now() + timedelta(days=14),
                    trial_end_date=datetime.now() + timedelta(days=14)
                )
            except SubscriptionPlan.DoesNotExist:
                pass
            
            messages.success(request, f'Organization "{organization.name}" created successfully!')
            return redirect('home')
    else:
        form = OrganizationSetupForm()
    
    return render(request, 'setup_organization.html', {'form': form})

class OrganizationCreateView(LoginRequiredMixin, CreateView):
    """Create new organization"""
    model = Organization
    form_class = OrganizationSetupForm
    template_name = 'setup_organization.html'
    success_url = '/'
    
    def form_valid(self, form):
        response = super().form_valid(form)
        
        # Assign user to organization
        self.request.user.organization = self.object
        self.request.user.role = 'admin'
        self.request.user.save()
        
        messages.success(self.request, f'Organization "{self.object.name}" created successfully!')
        return response