from django.urls import path
from . import views
from .tenant_views import setup_organization
from .superadmin_views import superadmin_dashboard, approve_organization_admin, reject_organization_admin

urlpatterns = [
    # Main pages
    path("", views.home, name="home"),
    path("contact/", views.contact, name="contact"),

    # Auth
    path("login/", views.CustomLoginView.as_view(), name="login"),
    path("logout/", views.custom_logout, name="logout"),
    path("register/", views.register, name="register"),
    
    # Organization Setup
    path("setup-organization/", setup_organization, name="setup_organization"),
    path("add-user/", views.add_user, name="add_user"),
    path("manage-users/", views.manage_users, name="manage_users"),
    path("toggle-user-status/<int:user_id>/", views.toggle_user_status, name="toggle_user_status"),
    
    # SuperAdmin
    path("superadmin/", superadmin_dashboard, name="superadmin_dashboard"),
    path("superadmin/approve/<int:user_id>/", approve_organization_admin, name="approve_organization_admin"),
    path("superadmin/reject/<int:user_id>/", reject_organization_admin, name="reject_organization_admin"),
    
    # Dashboards
    path("dashboard/admin/", views.admin_dashboard, name="admin_dashboard"),
    path("dashboard/trainer/", views.trainer_dashboard, name="trainer_dashboard"),
    path("dashboard/student/", views.student_dashboard, name="student_dashboard"),
    
    # Trainer course management
    path("trainer/course/create/", views.trainer_create_course, name="trainer_create_course"),
    path("trainer/course/<slug:slug>/edit/", views.trainer_edit_course, name="trainer_edit_course"),
    path("trainer/course/<slug:slug>/submit/", views.trainer_submit_for_review, name="trainer_submit_for_review"),
    
    # Admin course management
    path("dashboard/admin/course/create/", views.admin_create_course, name="admin_create_course"),
    path("dashboard/admin/courses/review/", views.admin_review_courses, name="admin_review_courses"),
    path("dashboard/admin/course/<slug:slug>/approve/", views.admin_approve_course, name="admin_approve_course"),
    path("dashboard/admin/course/<slug:slug>/reject/", views.admin_reject_course, name="admin_reject_course"),

    # Courses
    path("courses/", views.course_list, name="courses"),
    path("courses/<slug:slug>/", views.course_detail, name="course_detail"),
    path("courses/<slug:slug>/enroll/", views.enroll_course, name="enroll_course"),
    path("courses/<slug:slug>/like/", views.toggle_course_like, name="toggle_course_like"),

    # Trainers
    path("trainers/", views.trainer_list, name="trainers"),

    # Events
    path("events/", views.event_list, name="events"),
    path("events/<slug:slug>/", views.event_detail, name="event_detail"),
    path("events/<slug:slug>/register/", views.register_event, name="register_event"),

    # Newsletter
    path("newsletter/subscribe/", views.newsletter_subscribe, name="newsletter_subscribe"),

    # Tasks
    path('courses/<slug:slug>/tasks/', views.course_tasks, name='course_tasks'),
    path('courses/<slug:course_slug>/tasks/<int:task_id>/', views.task_detail, name='task_detail'),
    path('courses/<slug:course_slug>/tasks/<int:task_id>/submit/', views.submit_task, name='submit_task'),
    path('courses/<slug:course_slug>/tasks/<int:task_id>/timer-status/', views.get_timer_status, name='get_timer_status'),
    
    # Trainer dashboard functionality
    path('trainer/schedule/add/', views.add_class_schedule, name='add_class_schedule'),
    path('trainer/attendance/mark/', views.mark_attendance, name='mark_attendance'),
    path('trainer/notes/add/', views.add_training_note, name='add_training_note'),
    
    # Course Notes
    path('courses/<slug:slug>/notes/', views.course_notes, name='course_notes'),
    path('courses/<slug:slug>/notes/upload/', views.upload_course_note, name='upload_course_note'),
    path('courses/<slug:slug>/notes/<int:note_id>/view/', views.view_course_note, name='view_course_note'),
    path('courses/<slug:slug>/notes/<int:note_id>/file/', views.secure_file_view, name='secure_file_view'),
    path('courses/<slug:slug>/notes/<int:note_id>/edit/', views.edit_course_note, name='edit_course_note'),
    path('courses/<slug:slug>/notes/<int:note_id>/delete/', views.delete_course_note, name='delete_course_note'),
    
    # Profile
    path('profile/', views.profile_view, name='profile_view'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    
    # Admin Note Visibility Management
    path('manage/notes/visibiliy/', views.bulk_note_visibility, name='bulk_note_visibility'),
    path('manage/notes/visibility/<int:course_id>/', views.bulk_note_visibility, name='bulk_note_visibility_course'),
    path('manage/ajax/note-visibility/', views.ajax_note_visibility, name='ajax_note_visibility'),

] 