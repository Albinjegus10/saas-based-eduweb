from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Q, Count
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from datetime import datetime

from .models import *
from .forms import *
from .admin_views import bulk_note_visibility, ajax_note_visibility

def home(request):
    """Home page with featured courses and trainers"""
    context = {
        'featured_courses': Course.objects.filter(is_active=True, is_featured=True)[:6],
        'trainers': Trainer.objects.filter(is_active=True)[:4],
        'stats': {
            'students': User.objects.filter(role='student').count(),
            'courses': Course.objects.filter(is_active=True).count(),
            'events': Event.objects.filter(is_active=True).count(),
            'trainers': Trainer.objects.filter(is_active=True).count(),
        }
    }
    return render(request, 'home.html', context)

def course_list(request):
    """Courses listing with filters"""
    form = CourseSearchForm(request.GET)
    
    # Filter courses by organization for non-superusers
    if request.user.is_authenticated and not request.user.is_superuser and request.user.organization:
        courses = Course.objects.filter(is_active=True, organization=request.user.organization).select_related('trainer__user', 'category')
        categories = Category.objects.filter(is_active=True, organization=request.user.organization)
    else:
        courses = Course.objects.filter(is_active=True).select_related('trainer__user', 'category')
        categories = Category.objects.filter(is_active=True)
    
    if form.is_valid():
        # Search filter
        search = form.cleaned_data.get('search')
        if search:
            courses = courses.filter(
                Q(title__icontains=search) | 
                Q(description__icontains=search) |
                Q(category__name__icontains=search)
            )
        
        # Category filter
        category = form.cleaned_data.get('category')
        if category:
            courses = courses.filter(category=category)
        
        # Price range filter
        price_range = form.cleaned_data.get('price_range')
        if price_range:
            if price_range == '0-50':
                courses = courses.filter(price__lte=50)
            elif price_range == '50-100':
                courses = courses.filter(price__gt=50, price__lte=100)
            elif price_range == '100-200':
                courses = courses.filter(price__gt=100, price__lte=200)
            elif price_range == '200+':
                courses = courses.filter(price__gt=200)
        
        # Difficulty filter
        difficulty = form.cleaned_data.get('difficulty')
        if difficulty:
            courses = courses.filter(difficulty_level=difficulty)
    
    # Add annotations and ordering
    courses = courses.annotate(
    enrollment_count=Count('enrollments', filter=Q(enrollments__is_active=True)),
    total_likes=Count('likes')
).order_by('-created_at')
    
    # Pagination
    paginator = Paginator(courses, 9)
    page = request.GET.get('page')
    courses = paginator.get_page(page)
    
    # User's enrolled courses and likes (if authenticated)
    user_enrolled_courses = []
    user_liked_courses = []
    
    if request.user.is_authenticated:
        user_enrolled_courses = list(
            Enrollment.objects.filter(user=request.user, is_active=True)
            .values_list('course__slug', flat=True)
        )
        user_liked_courses = list(
            CourseLike.objects.filter(user=request.user)
            .values_list('course__slug', flat=True)
        )
    
    context = {
        'form': form,
        'courses': courses,
        'categories': categories,
        'is_paginated': courses.has_other_pages(),
        'page_obj': courses,
        'user_enrolled_courses': user_enrolled_courses,
        'user_liked_courses': user_liked_courses,
    }
    return render(request, 'courses.html', context)

def course_detail(request, slug):
    """Course detail page"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    
    context = {
        'course': course,
        'modules': course.modules.filter(is_active=True),
        'related_courses': Course.objects.filter(
            category=course.category, is_active=True
        ).exclude(id=course.id)[:3],
    }
    
    if request.user.is_authenticated:
        context['is_enrolled'] = Enrollment.objects.filter(
            user=request.user, course=course, is_active=True
        ).exists()
        context['has_liked'] = CourseLike.objects.filter(
            user=request.user, course=course
        ).exists()
    
    return render(request, 'course_detail.html', context)

def trainer_list(request):
    """Trainers listing"""
    # Filter trainers by organization for non-superusers
    if request.user.is_authenticated and not request.user.is_superuser and request.user.organization:
        trainers = Trainer.objects.filter(is_active=True, user__organization=request.user.organization).select_related('user').annotate(
            courses_count=Count('courses', filter=Q(courses__is_active=True)),
            students_count=Count('courses__enrollments', filter=Q(courses__enrollments__is_active=True))
        ).order_by('-created_at')
    else:
        trainers = Trainer.objects.filter(is_active=True).select_related('user').annotate(
            courses_count=Count('courses', filter=Q(courses__is_active=True)),
            students_count=Count('courses__enrollments', filter=Q(courses__enrollments__is_active=True))
        ).order_by('-created_at')
    
    # Search functionality
    search = request.GET.get('search')
    if search:
        trainers = trainers.filter(
            Q(user__first_name__icontains=search) |
            Q(user__last_name__icontains=search) |
            Q(expertise__icontains=search)
        )
    
    # Pagination
    paginator = Paginator(trainers, 12)
    page = request.GET.get('page')
    trainers = paginator.get_page(page)
    
    context = {
        'trainers': trainers,
        'is_paginated': trainers.has_other_pages(),
        'page_obj': trainers,
    }
    return render(request, 'trainers.html', context)

def event_list(request):
    """Events listing"""
    events = Event.objects.filter(is_active=True).select_related('trainer__user').annotate(
        attendees_count=Count('attendances')
    ).order_by('date')
    
    # Filter upcoming events
    filter_type = request.GET.get('filter', 'upcoming')
    now = datetime.now()
    
    if filter_type == 'upcoming':
        events = events.filter(date__gte=now)
    elif filter_type == 'past':
        events = events.filter(date__lt=now)
    
    # Search functionality
    search = request.GET.get('search')
    if search:
        events = events.filter(
            Q(title__icontains=search) |
            Q(description__icontains=search)
        )
    
    # Pagination
    paginator = Paginator(events, 12)
    page = request.GET.get('page')
    events = paginator.get_page(page)
    
    # User's registered events (if authenticated)
    user_registered_events = []
    if request.user.is_authenticated:
        user_registered_events = list(
            EventAttendance.objects.filter(user=request.user)
            .values_list('event__id', flat=True)
        )
    
    context = {
        'events': events,
        'user_registered_events': user_registered_events,
        'filter_type': filter_type,
        'is_paginated': events.has_other_pages(),
        'page_obj': events,
    }
    return render(request, 'events.html', context)

def event_detail(request, slug):
    """Event detail page with registration"""
    event = get_object_or_404(Event, slug=slug, is_active=True)
    
    context = {
        'event': event,
        'attendees_count': event.attendances.count(),
        'is_registered': False,
        'is_full': event.attendances.count() >= event.max_attendees if event.max_attendees else False,
    }
    
    if request.user.is_authenticated:
        context['is_registered'] = EventAttendance.objects.filter(
            user=request.user, event=event
        ).exists()
    
    return render(request, 'event_detail.html', context)

def register(request):
    """Public registration - Organization Admin only"""
    if request.method == 'POST':
        form = OrganizationAdminRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'admin'  # Force role to admin for public registration
            user.is_active = False  # Require superadmin approval
            user.save()
            
            messages.success(request, 'Organization Admin registration submitted! Please wait for approval from our team. You will receive an email once approved.')
            return redirect('home')
    else:
        form = OrganizationAdminRegistrationForm()
    
    context = {
        'form': form,
        'registration_type': 'Organization Admin'
    }
    return render(request, 'register.html', context)

@login_required
def add_user(request):
    """Organization Admin adds trainers and students"""
    if request.user.role != 'admin' or not request.user.organization:
        messages.error(request, 'Only organization admins can add users.')
        return redirect('home')
    
    if request.method == 'POST':
        form = AddUserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.organization = request.user.organization
            user.is_active = True  # Organization admin can directly activate
            user.save()
            
            # Create trainer profile if needed
            if user.role == 'trainer':
                Trainer.objects.create(
                    user=user,
                    expertise='Please update your expertise',
                    bio='Please update your bio'
                )
            
            messages.success(request, f'{user.get_role_display()} {user.get_full_name()} added successfully!')
            return redirect('admin_dashboard')
    else:
        form = AddUserForm()
    
    context = {
        'form': form,
        'organization': request.user.organization
    }
    return render(request, 'add_user.html', context)

@login_required
@require_POST
def enroll_course(request, slug):
    """Enroll user in course"""
    if request.user.role != 'student':
        messages.error(request, 'Only students can enroll in courses.')
        return redirect('course_detail', slug=slug)
    
    course = get_object_or_404(Course, slug=slug, is_active=True)
    
    # Check if course has available seats
    if course.remaining_seats <= 0:
        messages.error(request, 'Sorry, this course is full.')
        return redirect('course_detail', slug=course.slug)
    
    enrollment, created = Enrollment.objects.get_or_create(
        user=request.user,
        course=course,
        defaults={'status': 'active', 'is_active': True}
    )
    
    if created:
        messages.success(request, f'Successfully enrolled in {course.title}!')
    else:
        messages.info(request, 'You are already enrolled in this course.')
    
    return redirect('course_detail', slug=course.slug)

@login_required
@require_POST
def toggle_course_like(request, slug):
    """Toggle course like via AJAX"""
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        course = get_object_or_404(Course, slug=slug, is_active=True)
        
        like, created = CourseLike.objects.get_or_create(
            user=request.user,
            course=course
        )
        
        if not created:
            like.delete()
            liked = False
        else:
            liked = True
        
        return JsonResponse({
            'success': True,
            'liked': liked,
            'likes_count': course.likes.count()
        })
    
    return JsonResponse({'success': False})

@login_required
@require_POST
def register_event(request, slug):
    """Register for an event"""
    event = get_object_or_404(Event, slug=slug, is_active=True)
    
    # Check if event is full
    if event.max_attendees and event.attendances.count() >= event.max_attendees:
        messages.error(request, 'Sorry, this event is full.')
        return redirect('event_detail', slug=event.slug)
    
    attendance, created = EventAttendance.objects.get_or_create(
        user=request.user,
        event=event,
        defaults={'status': 'registered'}
    )
    
    if created:
        messages.success(request, f'Successfully registered for {event.title}!')
    else:
        messages.info(request, 'You are already registered for this event.')
    
    return redirect('event_detail', slug=event.slug)

@require_POST
def newsletter_subscribe(request):
    """Newsletter subscription"""
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        form = NewsletterForm(request.POST)
        if form.is_valid():
            form.save()
            return JsonResponse({
                'success': True,
                'message': 'Successfully subscribed to newsletter!'
            })
        else:
            return JsonResponse({
                'success': False,
                'message': 'Invalid email or already subscribed.'
            })
    
    return JsonResponse({'success': False, 'message': 'Invalid request'})

def contact(request):
    """Contact form handling"""
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Save the contact message
            contact_message = form.save()
            
            # Send email notification
            try:
                from django.core.mail import send_mail
                
                # Send email to admin
                subject = f"New Contact Message: {contact_message.subject}"
                message = f"""
New contact message received:

Name: {contact_message.name}
Email: {contact_message.email}
Subject: {contact_message.subject}

Message:
{contact_message.message}

Received at: {contact_message.created_at}
"""
                
                send_mail(
                    subject=subject,
                    message=message,
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=['jegusselvaraj@gmail.com'],
                    fail_silently=False,
                )
                
                email_sent = True
                
            except Exception as e:
                print(f"Email sending failed: {e}")
                email_sent = False
            
            # Handle AJAX requests
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'message': 'Message sent successfully! We will get back to you soon.'
                })
            
            messages.success(request, 'Message sent successfully! We will get back to you soon.')
            return redirect('contact')
        else:
            # Handle AJAX form errors
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False,
                    'errors': form.errors,
                    'message': 'Please correct the errors below.'
                })
    else:
        form = ContactForm()
    
    return render(request, 'contact.html', {'form': form})



# Task and Timer related views

@login_required
def course_tasks(request, slug):
    """Course tasks listing"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    
    # Check if user is enrolled
    is_enrolled = Enrollment.objects.filter(
        user=request.user, course=course, is_active=True
    ).exists()
    
    if not is_enrolled:
        messages.error(request, 'You must be enrolled in this course to view tasks.')
        return redirect('course_detail', slug=slug)
    
    tasks = course.tasks.filter(is_active=True)
    
    # Get user's submissions
    user_submissions = {}
    if request.user.is_authenticated:
        submissions = TaskSubmission.objects.filter(user=request.user, task__in=tasks)
        user_submissions = {sub.task_id: sub for sub in submissions}
    
    context = {
        'course': course,
        'tasks': tasks,
        'user_submissions': user_submissions,
        'is_enrolled': is_enrolled,
    }
    return render(request, 'course_tasks.html', context)

@login_required
def task_detail(request, course_slug, task_id):
    """Individual task detail and submission"""
    course = get_object_or_404(Course, slug=course_slug, is_active=True)
    task = get_object_or_404(Task, id=task_id, course=course, is_active=True)
    
    # Check if user is enrolled
    is_enrolled = Enrollment.objects.filter(
        user=request.user, course=course, is_active=True
    ).exists()
    
    if not is_enrolled:
        messages.error(request, 'You must be enrolled in this course to view this task.')
        return redirect('course_detail', slug=course_slug)
    
    # Get existing submission
    submission = None
    try:
        submission = TaskSubmission.objects.get(user=request.user, task=task)
    except TaskSubmission.DoesNotExist:
        pass
    
    # Check if task has started (for timer tracking)
    task_started = request.session.get(f'task_started_{task.id}', False)
    start_task_param = request.GET.get('start_task')
    
    # Auto-start timer for timed tasks when first accessed
    if not task_started and not submission and task.time_limit:
        if start_task_param == '1' or not request.session.get(f'task_viewed_{task.id}', False):
            start_time = timezone.now()
            request.session[f'task_started_{task.id}'] = True
            request.session[f'task_start_time_{task.id}'] = start_time.isoformat()
            request.session[f'task_viewed_{task.id}'] = True
            task_started = True
            if start_task_param == '1':
                messages.success(request, f'Task timer started! You have {task.time_limit} minutes to complete this task.')
            else:
                messages.info(request, f'Timer automatically started for this timed task. You have {task.time_limit} minutes to complete it.')
    
    # Check if timer has expired
    timer_expired = False
    if task_started and task.time_limit:
        start_time_str = request.session.get(f'task_start_time_{task.id}')
        if start_time_str:
            try:
                start_time = parse_datetime(start_time_str)
                if start_time:
                    current_time = timezone.now()
                    elapsed_seconds = (current_time - start_time).total_seconds()
                    total_seconds = task.time_limit * 60
                    timer_expired = elapsed_seconds >= total_seconds
            except:
                pass
    
    context = {
        'course': course,
        'task': task,
        'submission': submission,
        'is_enrolled': is_enrolled,
        'task_started': task_started or submission is not None,
        'timer_expired': timer_expired,
        'start_time': request.session.get(f'task_start_time_{task.id}') if task_started else None,
    }
    
    # Handle MCQ test
    if task.task_type == 'quiz':
        mcq_questions = task.mcq_questions.all()
        context['mcq_questions'] = mcq_questions
        
        # Get user's previous responses
        user_responses = {}
        if request.user.is_authenticated:
            responses = MCQResponse.objects.filter(user=request.user, question__task=task)
            user_responses = {resp.question_id: resp for resp in responses}
        context['user_responses'] = user_responses
        
        return render(request, 'mcq_test.html', context)
    
    return render(request, 'task_detail.html', context)

@login_required
@require_POST
def submit_task(request, course_slug, task_id):
    """Submit a task"""
    course = get_object_or_404(Course, slug=course_slug, is_active=True)
    task = get_object_or_404(Task, id=task_id, course=course, is_active=True)
    
    # Check enrollment
    is_enrolled = Enrollment.objects.filter(
        user=request.user, course=course, is_active=True
    ).exists()
    
    if not is_enrolled:
        messages.error(request, 'You must be enrolled to submit this task.')
        return redirect('course_detail', slug=course_slug)
    
    # Handle MCQ submission
    if task.task_type == 'quiz':
        return handle_mcq_submission(request, task)
    
    # Handle regular task submission
    submission_text = request.POST.get('submission_text', '').strip()
    file_upload = request.FILES.get('file_upload')
    
    # Validate submission - must have either text or file
    if not submission_text and not file_upload:
        messages.error(request, 'Please provide either text submission or upload a file before submitting.')
        return redirect('task_detail', course_slug=course_slug, task_id=task_id)
    
    submission, created = TaskSubmission.objects.get_or_create(
        user=request.user,
        task=task,
        defaults={
            'submission_text': submission_text,
            'file_upload': file_upload,
            'max_score': task.points
        }
    )
    
    if not created:
        # Update existing submission
        submission.submission_text = submission_text
        if file_upload:
            submission.file_upload = file_upload
        submission.status = 'submitted'
        submission.save()
    
    messages.success(request, 'Task submitted successfully!')
    return redirect('task_detail', course_slug=course_slug, task_id=task_id)

def handle_mcq_submission(request, task):
    """Handle MCQ test submission"""
    questions = task.mcq_questions.all()
    total_score = 0
    max_score = sum(q.points for q in questions)
    results = []
    answered_questions = 0
    
    # Check if any questions were answered
    has_answers = False
    for question in questions:
        selected_answer = request.POST.get(f'question_{question.id}')
        if selected_answer:
            has_answers = True
            answered_questions += 1
            
            response, created = MCQResponse.objects.get_or_create(
                user=request.user,
                question=question,
                defaults={'selected_answer': selected_answer}
            )
            
            if not created:
                response.selected_answer = selected_answer
                response.save()
            
            if response.is_correct:
                total_score += question.points
            
            results.append({
                'question_id': question.id,
                'selected': selected_answer,
                'correct': question.correct_answer,
                'is_correct': response.is_correct,
                'points': question.points if response.is_correct else 0
            })
    
    # Validate that at least some questions were answered (unless auto-submitted by timer)
    is_auto_submit = request.POST.get('auto_submit') == 'true'
    if not has_answers and not is_auto_submit:
        messages.error(request, 'Please answer at least one question before submitting the test.')
        return redirect('task_detail', course_slug=task.course.slug, task_id=task.id)
    
    # Create or update task submission
    submission, created = TaskSubmission.objects.get_or_create(
        user=request.user,
        task=task,
        defaults={
            'score': total_score,
            'max_score': max_score,
            'status': 'graded'
        }
    )
    
    if not created:
        submission.score = total_score
        submission.max_score = max_score
        submission.status = 'graded'
        submission.save()
    
    # Return JSON response for AJAX requests
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'success': True,
            'score': total_score,
            'max_score': max_score,
            'results': results,
            'answered_questions': answered_questions,
            'total_questions': questions.count(),
            'message': f'MCQ test completed! Your score: {total_score}/{max_score}'
        })
    
    if is_auto_submit:
        messages.warning(request, f'Time expired! Test auto-submitted. Your score: {total_score}/{max_score} (Answered {answered_questions}/{questions.count()} questions)')
    else:
        messages.success(request, f'MCQ test completed! Your score: {total_score}/{max_score}')
    return redirect('task_detail', course_slug=task.course.slug, task_id=task.id)

class CustomLoginView(LoginView):
    """Custom login view with role-based redirection"""
    template_name = 'registration/login.html'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        """Redirect users based on their role and organization status after login"""
        user = self.request.user
        
        # Superuser goes to superadmin dashboard
        if user.is_superuser:
            return reverse_lazy('superadmin_dashboard')
        
        # Check if user has organization - if not, redirect to setup
        if not user.organization:
            return reverse_lazy('setup_organization')
        
        # User has organization, redirect to appropriate dashboard
        if user.role == 'admin':
            return reverse_lazy('admin_dashboard')
        elif user.role == 'trainer':
            return reverse_lazy('trainer_dashboard')
        elif user.role == 'student':
            return reverse_lazy('student_dashboard')
        return reverse_lazy('home')
    
    def form_valid(self, form):
        """Add success message on login"""
        messages.success(self.request, f'Welcome back, {form.get_user().get_full_name()}!')
        return super().form_valid(form)
    
    def form_invalid(self, form):
        """Add error message on failed login"""
        messages.error(self.request, 'Invalid email or password. Please try again.')
        return super().form_invalid(form)

def custom_logout(request):
    """Custom logout view that handles both GET and POST requests"""
    user_name = request.user.get_full_name() if request.user.is_authenticated else 'User'
    logout(request)
    messages.success(request, f'Goodbye {user_name}! You have been successfully logged out.')
    return redirect('home')

# Dashboard views for different user roles
@login_required
def admin_dashboard(request):
    """Admin dashboard with system overview"""
    if request.user.role != 'admin':
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('home')
    
    # Get organization-specific data
    org = request.user.organization
    if org:
        org_users = User.objects.filter(organization=org)
        org_courses = Course.objects.filter(organization=org)
        
        context = {
            'organization': org,
            'subscription': getattr(org, 'subscription', None),
            'total_users': org_users.count(),
            'total_students': org_users.filter(role='student').count(),
            'total_trainers': org_users.filter(role='trainer').count(),
            'total_courses': org_courses.count(),
            'active_courses': org_courses.filter(is_active=True).count(),
            'total_enrollments': Enrollment.objects.filter(course__organization=org, is_active=True).count(),
            'recent_users': org_users.order_by('-created_at')[:5],
            'recent_courses': org_courses.order_by('-created_at')[:5],
        }
    else:
        context = {
            'total_users': 0,
            'total_students': 0,
            'total_trainers': 0,
            'total_courses': 0,
            'active_courses': 0,
            'total_enrollments': 0,
            'recent_users': [],
            'recent_courses': [],
        }
    
    return render(request, 'dashboards/admin_dashboard.html', context)

@login_required
def manage_users(request):
    """Organization admin manages users"""
    if request.user.role != 'admin' or not request.user.organization:
        messages.error(request, 'Only organization admins can manage users.')
        return redirect('home')
    
    org = request.user.organization
    users = User.objects.filter(organization=org).exclude(id=request.user.id).order_by('-created_at')
    
    # Filter by role if specified
    role_filter = request.GET.get('role')
    if role_filter in ['trainer', 'student']:
        users = users.filter(role=role_filter)
    
    # Search functionality
    search = request.GET.get('search')
    if search:
        users = users.filter(
            Q(first_name__icontains=search) |
            Q(last_name__icontains=search) |
            Q(email__icontains=search) |
            Q(username__icontains=search)
        )
    
    # Pagination
    paginator = Paginator(users, 20)
    page = request.GET.get('page')
    users = paginator.get_page(page)
    
    context = {
        'organization': org,
        'users': users,
        'role_filter': role_filter,
        'search': search,
        'total_users': User.objects.filter(organization=org).exclude(id=request.user.id).count(),
        'total_trainers': User.objects.filter(organization=org, role='trainer').count(),
        'total_students': User.objects.filter(organization=org, role='student').count(),
    }
    return render(request, 'manage_users.html', context)

@login_required
def trainer_dashboard(request):
    """Trainer dashboard with course management"""
    if request.user.role != 'trainer':
        messages.error(request, 'Access denied. Trainer privileges required.')
        return redirect('home')
    
    try:
        trainer = request.user.trainer_profile
    except Trainer.DoesNotExist:
        # Create trainer profile if it doesn't exist
        trainer = Trainer.objects.create(
            user=request.user,
            expertise='Please update your expertise',
            bio='Please update your bio'
        )
    
    context = {
        'trainer': trainer,
        'my_courses': trainer.courses.all(),
        'total_students': Enrollment.objects.filter(course__trainer=trainer, is_active=True, user__role='student').values('user').distinct().count(),
        'my_events': trainer.events.all(),
        'recent_enrollments': Enrollment.objects.filter(course__trainer=trainer).order_by('-enrolled_date')[:5],
        'class_schedules': ClassSchedule.objects.filter(trainer=trainer).order_by('-date', '-time')[:10],
        'recent_attendance': StudentAttendance.objects.filter(schedule__trainer=trainer).select_related('student', 'schedule__course').order_by('-created_at')[:20],
        'training_notes': TrainingNote.objects.filter(trainer=trainer).order_by('-created_at')[:10],
    }
    return render(request, 'dashboards/trainer_dashboard.html', context)

@login_required
def student_dashboard(request):
    """Student dashboard with enrolled courses"""
    if request.user.role != 'student':
        messages.error(request, 'Access denied. Student privileges required.')
        return redirect('home')
    
    enrollments = Enrollment.objects.filter(user=request.user, is_active=True)
    
    context = {
        'enrollments': enrollments,
        'total_courses': enrollments.count(),
        'completed_courses': enrollments.filter(status='completed').count(),
        'in_progress_courses': enrollments.filter(status='active').count(),
        'liked_courses': CourseLike.objects.filter(user=request.user),
        'recent_activities': enrollments.order_by('-enrolled_date')[:5],
    }
    return render(request, 'dashboards/student_dashboard.html', context)

# Course management views for trainers
@login_required
def trainer_create_course(request):
    """Allow trainers to create new courses"""
    if request.user.role != 'trainer':
        messages.error(request, 'Only trainers can create courses.')
        return redirect('home')
    
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.trainer = request.user.trainer_profile
            course.status = 'draft'  # Start as draft
            course.is_active = False  # Not active until approved
            course.save()
            messages.success(request, 'Course created successfully! It will be reviewed by admin before going live.')
            return redirect('trainer_dashboard')
    else:
        form = CourseForm()
    
    return render(request, 'courses/create_course.html', {'form': form})

@login_required
def trainer_edit_course(request, slug):
    """Allow trainers to edit their own courses"""
    course = get_object_or_404(Course, slug=slug, trainer__user=request.user)
    
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            course = form.save(commit=False)
            if course.status == 'approved':
                course.status = 'pending'  # Needs re-review if already approved
                messages.info(request, 'Course updated! Changes will be reviewed before going live.')
            else:
                messages.success(request, 'Course updated successfully!')
            course.save()
            return redirect('trainer_dashboard')
    else:
        form = CourseForm(instance=course)
    
    return render(request, 'courses/edit_course.html', {'form': form, 'course': course})

@login_required
def trainer_submit_for_review(request, slug):
    """Submit course for admin review"""
    course = get_object_or_404(Course, slug=slug, trainer__user=request.user)
    
    if course.status == 'draft':
        course.status = 'pending'
        course.save()
        messages.success(request, 'Course submitted for review!')
    else:
        messages.error(request, 'Course is not in draft status.')
    
    return redirect('trainer_dashboard')

# Admin course review views
@login_required
def admin_create_course(request):
    """Organization admin creates course"""
    if request.user.role != 'admin' or not request.user.organization:
        messages.error(request, 'Only organization admins can create courses.')
        return redirect('home')
    
    # Get trainers from the organization
    org_trainers = Trainer.objects.filter(user__organization=request.user.organization, is_active=True)
    
    if not org_trainers.exists():
        messages.error(request, 'No trainers available in your organization. Please add trainers first.')
        return redirect('admin_dashboard')
    
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        trainer_id = request.POST.get('trainer')
        
        if form.is_valid() and trainer_id:
            try:
                trainer = Trainer.objects.get(id=trainer_id, user__organization=request.user.organization)
                course = form.save(commit=False)
                course.trainer = trainer
                course.organization = request.user.organization
                course.status = 'approved'  # Admin can directly approve
                course.is_active = True
                course.reviewed_by = request.user
                course.reviewed_at = timezone.now()
                course.save()
                messages.success(request, f'Course "{course.title}" created and assigned to {trainer.user.get_full_name()}!')
                return redirect('admin_dashboard')
            except Trainer.DoesNotExist:
                messages.error(request, 'Invalid trainer selected.')
        else:
            if not trainer_id:
                messages.error(request, 'Please select a trainer for the course.')
    else:
        form = CourseForm()
    
    context = {
        'form': form,
        'trainers': org_trainers
    }
    return render(request, 'courses/admin_create_course.html', context)

@login_required
def admin_review_courses(request):
    """Admin view to review pending courses"""
    if request.user.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    # Only show courses from the admin's organization
    org = request.user.organization
    pending_courses = Course.objects.filter(status='pending', organization=org) if org else Course.objects.none()
    context = {
        'pending_courses': pending_courses
    }
    return render(request, 'admin/review_courses.html', context)

@login_required
def admin_approve_course(request, slug):
    """Admin approve course"""
    if request.user.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    course = get_object_or_404(Course, slug=slug)
    course.status = 'approved'
    course.is_active = True
    course.reviewed_by = request.user
    course.reviewed_at = timezone.now()
    course.save()
    
    messages.success(request, f'Course "{course.title}" approved and published!')
    return redirect('admin_review_courses')

@login_required
def admin_reject_course(request, slug):
    """Admin reject course"""
    if request.user.role != 'admin':
        messages.error(request, 'Access denied.')
        return redirect('home')
    
    course = get_object_or_404(Course, slug=slug)
    
    if request.method == 'POST':
        reason = request.POST.get('reason', '')
        course.status = 'rejected'
        course.rejection_reason = reason
        course.reviewed_by = request.user
        course.reviewed_at = timezone.now()
        course.save()
        
        messages.success(request, f'Course "{course.title}" rejected.')
        return redirect('admin_review_courses')
    
    return render(request, 'admin/reject_course.html', {'course': course})

# Class Schedule Management Views
@login_required
@require_POST
def add_class_schedule(request):
    """Add a new class schedule"""
    if request.user.role != 'trainer':
        return JsonResponse({'success': False, 'message': 'Access denied'})
    
    try:
        trainer = request.user.trainer_profile
        course_id = request.POST.get('course_id')
        date = request.POST.get('date')
        time = request.POST.get('time')
        topic = request.POST.get('topic', '')
        
        course = Course.objects.get(id=course_id, trainer=trainer)
        
        schedule = ClassSchedule.objects.create(
            course=course,
            trainer=trainer,
            date=date,
            time=time,
            topic=topic
        )
        
        return JsonResponse({
            'success': True,
            'message': 'Class schedule added successfully!',
            'schedule_id': schedule.id
        })
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})

@login_required
@require_POST
def mark_attendance(request):
    """Mark student attendance"""
    if request.user.role != 'trainer':
        return JsonResponse({'success': False, 'message': 'Access denied'})
    
    try:
        trainer = request.user.trainer_profile
        schedule_id = request.POST.get('schedule_id')
        
        schedule = ClassSchedule.objects.get(id=schedule_id, trainer=trainer)
        
        # Get all enrolled students for this course
        enrolled_students = User.objects.filter(
            enrollments__course=schedule.course,
            enrollments__is_active=True,
            role='student'
        )
        
        attendance_count = 0
        for student in enrolled_students:
            status = request.POST.get(f'student_{student.id}', 'absent')
            
            attendance, created = StudentAttendance.objects.get_or_create(
                schedule=schedule,
                student=student,
                defaults={
                    'status': status,
                    'marked_by': request.user
                }
            )
            
            if not created:
                attendance.status = status
                attendance.save()
            
            attendance_count += 1
        
        return JsonResponse({
            'success': True,
            'message': f'Attendance marked for {attendance_count} students!'
        })
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})

@login_required
@require_POST
def add_training_note(request):
    """Add a new training note"""
    if request.user.role != 'trainer':
        return JsonResponse({'success': False, 'message': 'Access denied'})
    
    try:
        trainer = request.user.trainer_profile
        title = request.POST.get('title')
        content = request.POST.get('content')
        course_id = request.POST.get('course_id')
        tags = request.POST.get('tags', '')
        
        course = None
        if course_id:
            course = Course.objects.get(id=course_id, trainer=trainer)
        
        note = TrainingNote.objects.create(
            trainer=trainer,
            course=course,
            title=title,
            content=content,
            tags=tags
        )
        
        return JsonResponse({
            'success': True,
            'message': 'Training note added successfully!',
            'note_id': note.id
        })
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})

@login_required
def get_timer_status(request, course_slug, task_id):
    """Get remaining time for a task"""
    course = get_object_or_404(Course, slug=course_slug, is_active=True)
    task = get_object_or_404(Task, id=task_id, course=course, is_active=True)
    
    # Check if user is enrolled
    is_enrolled = Enrollment.objects.filter(
        user=request.user, course=course, is_active=True
    ).exists()
    
    if not is_enrolled:
        return JsonResponse({'error': 'Not enrolled'}, status=403)
    
    # Check if task has time limit
    if not task.time_limit:
        return JsonResponse({'has_timer': False})
    
    # Check if task is started
    task_started = request.session.get(f'task_started_{task.id}', False)
    if not task_started:
        return JsonResponse({'has_timer': False})
    
    # Get task start time from session
    start_time_str = request.session.get(f'task_start_time_{task.id}')
    if not start_time_str:
        return JsonResponse({'has_timer': False})
    
    try:
        start_time = parse_datetime(start_time_str)
        if not start_time:
            return JsonResponse({'error': 'Invalid timer data'}, status=400)
            
        current_time = timezone.now()
        elapsed_seconds = (current_time - start_time).total_seconds()
        total_seconds = task.time_limit * 60
        remaining_seconds = max(0, total_seconds - elapsed_seconds)
        
        # Calculate hours, minutes, seconds
        hours = int(remaining_seconds // 3600)
        minutes = int((remaining_seconds % 3600) // 60)
        seconds = int(remaining_seconds % 60)
        
        return JsonResponse({
            'has_timer': True,
            'remaining_seconds': int(remaining_seconds),
            'hours': hours,
            'minutes': minutes,
            'seconds': seconds,
            'expired': remaining_seconds <= 0
        })
    except Exception as e:
        return JsonResponse({'error': 'Invalid timer data'}, status=400)

# Course Notes Views
@login_required
def course_notes(request, slug):
    """View course notes for enrolled students or trainers"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    
    # Check if user has access to course notes
    has_access = False
    if request.user.role == 'trainer' and hasattr(request.user, 'trainer_profile'):
        has_access = course.trainer == request.user.trainer_profile
    elif request.user.role == 'student':
        has_access = Enrollment.objects.filter(
            user=request.user, course=course, is_active=True
        ).exists()
    elif request.user.role == 'admin':
        has_access = True
    
    if not has_access:
        messages.error(request, 'You must be enrolled in this course to view notes.')
        return redirect('course_detail', slug=slug)
    
    # Filter notes based on visibility settings
    notes = course.notes.filter(is_active=True)
    
    if request.user.role == 'student':
        # For students, filter based on visibility settings
        from django.db.models import Q
        notes = notes.filter(
            Q(is_restricted=False) |  # Unrestricted notes (visible to all enrolled)
            Q(is_restricted=True, visible_to_students=request.user)  # Restricted but user is selected
        )
    # Trainers and admins can see all notes
    
    notes = notes.order_by('order', 'created_at')
    
    context = {
        'course': course,
        'notes': notes,
        'is_trainer': request.user.role == 'trainer' and hasattr(request.user, 'trainer_profile') and course.trainer == request.user.trainer_profile,
    }
    return render(request, 'course_notes.html', context)

@login_required
def upload_course_note(request, slug):
    """Upload course note (trainers only)"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    
    # Check if user is the trainer of this course
    if request.user.role != 'trainer' or not hasattr(request.user, 'trainer_profile'):
        messages.error(request, 'Only trainers can upload course notes.')
        return redirect('course_detail', slug=slug)
    
    if course.trainer != request.user.trainer_profile:
        messages.error(request, 'You can only upload notes for your own courses.')
        return redirect('course_detail', slug=slug)
    
    if request.method == 'POST':
        form = CourseNoteForm(request.POST, request.FILES)
        if form.is_valid():
            note = form.save(commit=False)
            note.course = course
            note.trainer = request.user.trainer_profile
            note.save()
            messages.success(request, 'Course note uploaded successfully!')
            return redirect('course_notes', slug=slug)
    else:
        form = CourseNoteForm()
    
    context = {
        'course': course,
        'form': form,
    }
    return render(request, 'upload_course_note.html', context)

@login_required
def view_course_note(request, slug, note_id):
    """View course note content (view-only, no download)"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    note = get_object_or_404(CourseNote, id=note_id, course=course, is_active=True)
    
    # Check if user has access
    has_access = False
    if request.user.role == 'trainer' and hasattr(request.user, 'trainer_profile'):
        has_access = course.trainer == request.user.trainer_profile
    elif request.user.role == 'student':
        # Check enrollment and visibility settings
        is_enrolled = Enrollment.objects.filter(
            user=request.user, course=course, is_active=True
        ).exists()
        
        if is_enrolled:
            # Check note visibility
            if not note.is_restricted:
                has_access = True  # Unrestricted note, all enrolled can view
            else:
                has_access = note.visible_to_students.filter(id=request.user.id).exists()
    elif request.user.role == 'admin':
        has_access = True
    
    if not has_access:
        messages.error(request, 'You do not have permission to view this note.')
        return redirect('course_notes', slug=slug)
    
    context = {
        'course': course,
        'note': note,
        'is_trainer': request.user.role == 'trainer' and hasattr(request.user, 'trainer_profile') and course.trainer == request.user.trainer_profile,
    }
    return render(request, 'view_course_note.html', context)

@login_required
@require_POST
def delete_course_note(request, slug, note_id):
    """Delete course note (trainers only)"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    note = get_object_or_404(CourseNote, id=note_id, course=course)
    
    # Check if user is the trainer of this course
    if request.user.role != 'trainer' or not hasattr(request.user, 'trainer_profile'):
        messages.error(request, 'Access denied.')
        return redirect('course_notes', slug=slug)
    
    if course.trainer != request.user.trainer_profile:
        messages.error(request, 'You can only delete notes from your own courses.')
        return redirect('course_notes', slug=slug)
    
    note.delete()
    messages.success(request, 'Course note deleted successfully!')
    return redirect('course_notes', slug=slug)

@login_required
def edit_course_note(request, slug, note_id):
    """Edit course note (trainers only)"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    note = get_object_or_404(CourseNote, id=note_id, course=course)
    
    # Check if user is the trainer of this course
    if request.user.role != 'trainer' or not hasattr(request.user, 'trainer_profile'):
        messages.error(request, 'Access denied.')
        return redirect('course_notes', slug=slug)
    
    if course.trainer != request.user.trainer_profile:
        messages.error(request, 'You can only edit notes from your own courses.')
        return redirect('course_notes', slug=slug)
    
    if request.method == 'POST':
        form = CourseNoteForm(request.POST, request.FILES, instance=note)
        if form.is_valid():
            form.save()
            messages.success(request, 'Course note updated successfully!')
            return redirect('course_notes', slug=slug)
    else:
        form = CourseNoteForm(instance=note)
    
    context = {
        'course': course,
        'note': note,
        'form': form,
    }
    return render(request, 'edit_course_note.html', context)

@login_required
def secure_file_view(request, slug, note_id):
    """Serve file for viewing only (no download)"""
    course = get_object_or_404(Course, slug=slug, is_active=True)
    note = get_object_or_404(CourseNote, id=note_id, course=course, is_active=True)
    
    # Check access with visibility settings
    has_access = False
    if request.user.role == 'trainer' and hasattr(request.user, 'trainer_profile'):
        has_access = course.trainer == request.user.trainer_profile
    elif request.user.role == 'student':
        # Check enrollment and visibility settings
        is_enrolled = Enrollment.objects.filter(
            user=request.user, course=course, is_active=True
        ).exists()
        
        if is_enrolled:
            # Check note visibility
            if not note.is_restricted:
                has_access = True  # Unrestricted note, all enrolled can view
            else:
                has_access = note.visible_to_students.filter(id=request.user.id).exists()
    elif request.user.role == 'admin':
        has_access = True
    
    if not has_access:
        return HttpResponse('Access denied', status=403)
    
    from django.http import FileResponse, HttpResponse
    import os
    
    try:
        file_path = note.file.path
        if not os.path.exists(file_path):
            return HttpResponse('File not found', status=404)
        
        file_handle = open(file_path, 'rb')
        
        content_types = {
            'pdf': 'application/pdf',
            'txt': 'text/plain',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif'
        }
        
        content_type = content_types.get(note.file_type, 'application/octet-stream')
        
        response = FileResponse(file_handle, content_type=content_type)
        response['Content-Disposition'] = 'inline'
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'SAMEORIGIN'
        response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response['Pragma'] = 'no-cache'
        
        return response
        
    except Exception as e:
        return HttpResponse('Error loading file', status=500)

# Profile Views
@login_required
def profile_view(request):
    """View user profile"""
    context = {
        'user': request.user,
    }
    
    if request.user.role == 'trainer':
        try:
            context['trainer'] = request.user.trainer_profile
        except Trainer.DoesNotExist:
            context['trainer'] = None
    
    return render(request, 'profile/profile.html', context)

@login_required
def profile_edit(request):
    """Edit user profile"""
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user, user_id=request.user.id)
        trainer_form = None
        
        if request.user.role == 'trainer':
            try:
                trainer = request.user.trainer_profile
                trainer_form = TrainerProfileForm(request.POST, request.FILES, instance=trainer)
            except Trainer.DoesNotExist:
                trainer_form = TrainerProfileForm(request.POST, request.FILES)
        
        if form.is_valid():
            form.save()
            
            if trainer_form and trainer_form.is_valid():
                trainer = trainer_form.save(commit=False)
                trainer.user = request.user
                trainer.save()
            
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile_view')
    else:
        form = UserProfileForm(instance=request.user, user_id=request.user.id)
        trainer_form = None
        
        if request.user.role == 'trainer':
            try:
                trainer = request.user.trainer_profile
                trainer_form = TrainerProfileForm(instance=trainer)
            except Trainer.DoesNotExist:
                trainer_form = TrainerProfileForm()
    
    context = {
        'form': form,
        'trainer_form': trainer_form,
    }
    return render(request, 'profile/edit_profile.html', context)

@login_required
@require_POST
def toggle_user_status(request, user_id):
    """Toggle user active status (organization admin only)"""
    if request.user.role != 'admin' or not request.user.organization:
        return JsonResponse({'success': False, 'message': 'Access denied'})
    
    try:
        user = User.objects.get(id=user_id, organization=request.user.organization)
        if user.role == 'admin':
            return JsonResponse({'success': False, 'message': 'Cannot modify admin users'})
        
        user.is_active = not user.is_active
        user.save()
        
        status = 'activated' if user.is_active else 'deactivated'
        return JsonResponse({
            'success': True,
            'message': f'User {user.get_full_name()} {status} successfully',
            'is_active': user.is_active
        })
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'User not found'})
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})

