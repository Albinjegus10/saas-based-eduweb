#!/usr/bin/env python
"""
Script to check database status and multi-tenancy setup
"""
import mysql.connector
import os
from decouple import config

def check_database():
    try:
        # Database connection parameters
        db_config = {
            'host': config('DB_HOST', default='127.0.0.1'),
            'user': config('DB_USER', default='root'),
            'password': config('DB_PASSWORD', default='root'),
            'port': config('DB_PORT', default='3306', cast=int)
        }
        
        print("Checking database connection...")
        
        # Connect to MySQL server
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        
        # Check if database exists
        db_name = 'edunew_saas'
        cursor.execute("SHOW DATABASES")
        databases = [db[0] for db in cursor.fetchall()]
        
        print(f"\nAvailable databases: {databases}")
        
        if db_name in databases:
            print(f"Database '{db_name}' exists - OK")
            
            # Connect to the specific database
            cursor.execute(f"USE {db_name}")
            
            # Check tables
            cursor.execute("SHOW TABLES")
            tables = [table[0] for table in cursor.fetchall()]
            
            print(f"\nTables in {db_name}:")
            for table in sorted(tables):
                print(f"  - {table}")
            
            # Check for multi-tenant tables
            multi_tenant_tables = [
                'basic_organization',
                'basic_subscriptionplan', 
                'basic_subscription',
                'basic_paymentgateway',
                'basic_payment'
            ]
            
            print(f"\nMulti-tenant tables status:")
            for table in multi_tenant_tables:
                if table in tables:
                    print(f"  OK {table}")
                else:
                    print(f"  MISSING {table}")
            
            # Check if User table has organization field
            try:
                cursor.execute("DESCRIBE basic_user")
                columns = [col[0] for col in cursor.fetchall()]
                if 'organization_id' in columns:
                    print("  OK User model has organization field")
                else:
                    print("  MISSING User model organization field")
            except:
                print("  ERROR Could not check User table structure")
                
        else:
            print(f"ERROR Database '{db_name}' does not exist")
            print("Run: python manage.py migrate to create it")
        
        cursor.close()
        connection.close()
        
        return True
        
    except mysql.connector.Error as err:
        print(f"Database Error: {err}")
        return False
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    check_database()