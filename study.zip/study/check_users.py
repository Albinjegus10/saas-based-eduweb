#!/usr/bin/env python
"""
Script to check user table data
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'study.settings')
django.setup()

from basic.models import User, Organization

def check_users():
    print("=== USER TABLE DATA ===")
    users = User.objects.all()
    
    for user in users:
        print(f"\nUser ID: {user.id}")
        print(f"Username: {user.username}")
        print(f"Email: {user.email}")
        print(f"Name: {user.get_full_name()}")
        print(f"Role: {user.role}")
        print(f"Is Active: {user.is_active}")
        print(f"Is Superuser: {user.is_superuser}")
        print(f"Is Staff: {user.is_staff}")
        print(f"Organization: {user.organization}")
        print(f"Created: {user.created_at}")
        print("-" * 50)
    
    print(f"\nTotal Users: {users.count()}")
    print(f"Active Users: {users.filter(is_active=True).count()}")
    print(f"Inactive Users: {users.filter(is_active=False).count()}")
    print(f"Superusers: {users.filter(is_superuser=True).count()}")
    
    print("\n=== ORGANIZATION TABLE DATA ===")
    orgs = Organization.objects.all()
    for org in orgs:
        print(f"\nOrg ID: {org.id}")
        print(f"Name: {org.name}")
        print(f"Contact: {org.contact_email}")
        print(f"Active: {org.is_active}")
        print(f"Users: {org.users.count()}")
        print("-" * 30)

if __name__ == "__main__":
    check_users()