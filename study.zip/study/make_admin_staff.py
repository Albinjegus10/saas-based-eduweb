#!/usr/bin/env python
"""
Script to make organization admins staff users
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'study.settings')
django.setup()

from basic.models import User

def make_admins_staff():
    admins = User.objects.filter(role='admin', is_active=True)
    
    for admin in admins:
        if not admin.is_staff:
            admin.is_staff = True
            admin.save()
            print(f"Made {admin.email} staff user")
        else:
            print(f"{admin.email} is already staff")
    
    print(f"\nProcessed {admins.count()} admin users")

if __name__ == "__main__":
    make_admins_staff()