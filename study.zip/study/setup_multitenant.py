#!/usr/bin/env python
"""
Script to set up multi-tenant database
"""
import os
import django
import sys

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'study.settings')
django.setup()

from django.core.management import execute_from_command_line

def setup_multitenant():
    print("Setting up Multi-Tenant SaaS Database...")
    
    try:
        # Create migrations
        print("\nCreating migrations...")
        execute_from_command_line(['manage.py', 'makemigrations', 'basic'])
        
        # Apply migrations
        print("\nApplying migrations...")
        execute_from_command_line(['manage.py', 'migrate'])
        
        # Create subscription plans
        print("\nCreating subscription plans...")
        execute_from_command_line(['manage.py', 'create_subscription_plans'])
        
        # Create superuser prompt
        print("\nCreate superuser account:")
        execute_from_command_line(['manage.py', 'createsuperuser'])
        
        print("\nMulti-tenant setup completed successfully!")
        print("\nNext steps:")
        print("1. Run: python manage.py runserver")
        print("2. Visit: http://127.0.0.1:8000/register")
        print("3. Register as a new user")
        print("4. Set up your organization")
        print("5. Start using your SaaS platform!")
        
    except Exception as e:
        print(f"\nError during setup: {e}")
        return False
    
    return True

if __name__ == "__main__":
    setup_multitenant()