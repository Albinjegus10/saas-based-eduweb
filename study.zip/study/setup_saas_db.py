#!/usr/bin/env python
"""
Script to set up a new database for SaaS features
"""
import mysql.connector
import os
from decouple import config

def create_database():
    try:
        # Database connection parameters
        db_config = {
            'host': config('DB_HOST', default='127.0.0.1'),
            'user': config('DB_USER', default='root'),
            'password': config('DB_PASSWORD', default='root'),
            'port': config('DB_PORT', default='3306', cast=int)
        }
        
        # Connect to MySQL server
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        
        # Create new database
        db_name = 'edunew_saas'
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        print(f"✅ Database '{db_name}' created successfully!")
        
        # Show databases to confirm
        cursor.execute("SHOW DATABASES")
        databases = cursor.fetchall()
        print("\n📋 Available databases:")
        for db in databases:
            print(f"  - {db[0]}")
        
        cursor.close()
        connection.close()
        
        return True
        
    except mysql.connector.Error as err:
        print(f"❌ Error: {err}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Setting up new SaaS database...")
    if create_database():
        print("\n✅ Database setup completed!")
        print("\nNext steps:")
        print("1. Run: python manage.py makemigrations")
        print("2. Run: python manage.py migrate")
        print("3. Run: python manage.py createsuperuser")
    else:
        print("\n❌ Database setup failed!")