#!/usr/bin/env python
import os
import sys
import django

# Add the project directory to Python path
sys.path.append('d:/educationnew/study')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'study.settings')

# Setup Django
django.setup()

from django.core.mail import send_mail
from django.conf import settings

def test_email():
    try:
        print("Testing email configuration...")
        print(f"EMAIL_HOST: {settings.EMAIL_HOST}")
        print(f"EMAIL_PORT: {settings.EMAIL_PORT}")
        print(f"EMAIL_HOST_USER: {settings.EMAIL_HOST_USER}")
        print(f"DEFAULT_FROM_EMAIL: {settings.DEFAULT_FROM_EMAIL}")
        
        # Send test email
        send_mail(
            subject='Test Email from Contact Form',
            message='This is a test email to verify the email configuration is working.',
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=['jegusselvaraj@gmail.com'],
            fail_silently=False,
        )
        print("✅ Email sent successfully!")
        
    except Exception as e:
        print(f"❌ Email sending failed: {e}")

if __name__ == '__main__':
    test_email()